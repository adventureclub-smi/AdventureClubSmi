import { prisma } from "@/lib/prisma";
import { notFound } from "next/navigation";
import TrekDetails from "@/components/treks/TrekDetails";
import { getCurrentUser } from "@/lib/current-user";

export default async function TrekPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;

  const user = await getCurrentUser();

  const trek = await prisma.trek.findUnique({
    where: {
      id,
    },
  });

  if (!trek) {
    notFound();
  }

  let registration = null;

  if (user) {
    registration = await prisma.registration.findFirst({
      where: {
        trekId: trek.id,
        userId: user.id,
      },
      include: {
        payments: true,
      },
    });
    console.log("USER:", user?.id);
console.log("TREK:", trek.id);
console.log("REGISTRATION:", registration);
  }

  return (
    <TrekDetails
      trek={trek}
      user={user}
      registration={registration}
    />
  );
}