import StudentTreks from "@/components/treks/StudentTreks";

export default function TreksPage() {
  return <StudentTreks />;
}