export default function RegistrationsPage() {
  return (
    <div style={{ padding: 40 }}>
      <h1>Global Registrations</h1>
      <p>Coming soon...</p>
    </div>
  );
}