import CreateTrekForm from "@/components/admin/CreateTrekForm";

export default function EditTrekPage() {
  return <CreateTrekForm />;
}