"use client";

import { useEffect, useState } from "react";

export default function PaymentSettingsPage() {
  const [clubName, setClubName] = useState("");
  const [receiverName, setReceiverName] = useState("");
  const [upiId, setUpiId] = useState("");
  const [supportPhone, setSupportPhone] = useState("");

  useEffect(() => {
    load();
  }, []);

  async function load() {
    const res = await fetch("/api/admin/settings/payment");

    if (!res.ok) return;

    const data = await res.json();

    setClubName(data.clubName ?? "");
    setReceiverName(data.receiverName ?? "");
    setUpiId(data.upiId ?? "");
    setSupportPhone(data.supportPhone ?? "");
  }

  async function save() {
    const res = await fetch("/api/admin/settings/payment", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        clubName,
        receiverName,
        upiId,
        supportPhone,
      }),
    });

    if (res.ok) {
      alert("Payment settings saved.");
    } else {
      alert("Failed to save.");
    }
  }

  return (
    <div
      style={{
        maxWidth: 700,
        margin: "40px auto",
        padding: 30,
        background: "#111827",
        borderRadius: 16,
        color: "white",
      }}
    >
      <h1>Payment Settings</h1>

      <br />

      <label>Club Name</label>

      <input
        value={clubName}
        onChange={(e) => setClubName(e.target.value)}
        style={input}
      />

      <label>Receiver Name</label>

      <input
        value={receiverName}
        onChange={(e) => setReceiverName(e.target.value)}
        style={input}
      />

      <label>UPI ID</label>

      <input
        value={upiId}
        onChange={(e) => setUpiId(e.target.value)}
        style={input}
      />

      <label>Support Phone</label>

      <input
        value={supportPhone}
        onChange={(e) => setSupportPhone(e.target.value)}
        style={input}
      />

      <button
        onClick={save}
        style={{
          marginTop: 25,
          width: "100%",
          padding: 15,
          background: "#22c55e",
          border: "none",
          borderRadius: 10,
          color: "white",
          fontWeight: 700,
          cursor: "pointer",
        }}
      >
        Save Settings
      </button>
    </div>
  );
}

const input = {
  width: "100%",
  padding: 12,
  marginTop: 8,
  marginBottom: 20,
  borderRadius: 8,
  border: "1px solid #333",
  background: "#1f2937",
  color: "white",
};