import Link from "next/link";

export default function SettingsPage() {
  return (
    <div style={{ padding: 40 }}>
      <h1>Admin Settings</h1>

      <br />

      <Link href="/admin/settings/payment">
        💳 Payment Settings
      </Link>
    </div>
  );
}