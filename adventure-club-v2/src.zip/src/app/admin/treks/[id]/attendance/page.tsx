import AttendanceTab from "@/components/admin/AttendanceTab";

export default async function Page({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;

  return <AttendanceTab trekId={id} />;
}