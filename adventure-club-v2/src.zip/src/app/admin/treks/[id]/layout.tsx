
import { ReactNode } from "react";
import { prisma } from "@/lib/prisma";
import styles from "./layout.module.scss";
import TrekTabs from "@/components/admin/TrekTabs";

export default async function TrekLayout({
  children,
  params,
}: {
  children: ReactNode;
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;

  const trek = await prisma.trek.findUnique({
    where: { id },
  });

  if (!trek) {
    return <h1>Trek not found.</h1>;
  }

 const tabs = [
  {
    title: "Overview",
    href: `/admin/treks/${id}`,
  },
  {
    title: "Registrations",
    href: `/admin/treks/${id}/registrations`,
  },
  {
    title: "Payments",
    href: `/admin/treks/${id}/payments`,
  },
  {
    title: "Attendance",
    href: `/admin/treks/${id}/attendance`,
  },
  {
    title: "Trip Centre",
    href: `/admin/treks/${id}/trip-centre`,
  },
  {
    title: "Finance",
    href: `/admin/treks/${id}/finance`,
  },
  {
    title: "Gallery",
    href: `/admin/treks/${id}/gallery`,
  },
  {
    title: "Reports",
    href: `/admin/treks/${id}/reports`,
  },
];

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <div>
          <h1>{trek.title}</h1>

          <p>{trek.destination}</p>

          <div className={styles.stats}>
            <span>📅 {new Date(trek.date).toLocaleDateString()}</span>
            <span>🥾 {trek.difficulty}</span>
            <span>💰 ₹{trek.price}</span>
            <span>👥 {trek.seats} Seats</span>
          </div>
        </div>
      </div>

      <TrekTabs tabs={tabs} />

      <div className={styles.content}>{children}</div>
    </div>
  );
}