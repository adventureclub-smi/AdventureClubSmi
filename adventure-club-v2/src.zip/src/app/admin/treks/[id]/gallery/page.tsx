import AttendanceTab from "@/components/admin/AttendanceTab";

export default async function AttendancePage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;

  return <AttendanceTab trekId={id} />;
}