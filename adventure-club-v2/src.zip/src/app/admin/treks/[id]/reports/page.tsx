export default function Page() {
  return (
    <div>
      <h1>Reports Module</h1>
      <p>Coming Soon...</p>
    </div>
  );
}