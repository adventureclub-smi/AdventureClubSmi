export default function Page() {
  return (
    <div>
      <h1>Gallery Module</h1>
      <p>Coming Soon...</p>
    </div>
  );
}