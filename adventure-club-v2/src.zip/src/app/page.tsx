import Navbar from "@/components/layout/Navbar";
import Hero from "@/components/hero/Hero";
import NextAdventureServer from "@/components/home/NextAdventureServer";
import FeaturedTrek from "@/components/home/FeaturedTrek";
import About from "@/components/sections/About";
import Activities from "@/components/sections/Activities";
import styles from "./page.module.scss";

export default function Home() {
  return (
    <>
      <Navbar />

      <Hero />

      <div className={styles.heroCountdown}>
        <NextAdventureServer />
      </div>

      <FeaturedTrek />

      <About />

      <Activities />
    </>
  );
}