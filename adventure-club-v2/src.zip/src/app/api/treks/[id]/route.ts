import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

type RouteContext = {
  params: Promise<{
    id: string;
  }>;
};

export async function GET(
  req: Request,
  context: RouteContext
) {
  try {
    const { id } = await context.params;

    const trek = await prisma.trek.findUnique({
      where: { id },
    });

    if (!trek) {
      return NextResponse.json(
        { message: "Trek not found." },
        { status: 404 }
      );
    }

    return NextResponse.json(trek);
  } catch (error) {
    console.error(error);

    return NextResponse.json(
      { message: "Failed to fetch trek." },
      { status: 500 }
    );
  }
}

export async function PUT(
  req: Request,
  context: RouteContext
) {
  try {
    const { id } = await context.params;

    const body = await req.json();

    const trek = await prisma.trek.update({
      where: { id },
      data: {
        title: body.title,
        destination: body.destination,
        trailType: body.trailType,
        difficulty: body.difficulty,
        altitude: body.altitude,
        duration: body.duration,
        distance: body.distance,
        trekDay: body.trekDay,
        date: new Date(body.date),
        price: Number(body.price),
        initialPayment: Number(body.initialPayment),
        finalPayment: Number(body.finalPayment),
        seats: Number(body.seats),
        description: body.description,
        status: body.status,
      },
    });

    return NextResponse.json({
      message: "Trek updated successfully!",
      trek,
    });
  } catch (error) {
    console.error(error);

    return NextResponse.json(
      { message: "Failed to update trek." },
      { status: 500 }
    );
  }
}

export async function DELETE(
  req: Request,
  context: RouteContext
) {
  try {
    const { id } = await context.params;

    await prisma.trek.delete({
      where: { id },
    });

    return NextResponse.json({
      message: "Trek deleted successfully!",
    });
  } catch (error) {
    console.error(error);

    return NextResponse.json(
      { message: "Failed to delete trek." },
      { status: 500 }
    );
  }
}