import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function POST(req: Request) {
  try {
    const body = await req.json();

    const {
      title,
      destination,
      trailType,
      difficulty,
      altitude,
      duration,
      distance,
      trekDay,
      date,
      price,
      initialPayment,
      finalPayment,
      seats,
      description,
      coverImage,

      // NEW
      registrationOpensAt,
      registrationClosesAt,
    } = body;

    if (
      !title ||
      !destination ||
      !trailType ||
      !difficulty ||
      !altitude ||
      !duration ||
      !distance ||
      !trekDay ||
      !date ||
      !price ||
      !initialPayment ||
      !finalPayment ||
      !seats ||
      !description
    ) {
      return NextResponse.json(
        {
          message: "Please fill all fields.",
        },
        {
          status: 400,
        }
      );
    }

    const trek = await prisma.trek.create({
      data: {
        title,
        destination,
        trailType,
        difficulty,
        altitude,
        duration,
        distance,
        trekDay,

        date: new Date(date),

        price: Number(price),

        initialPayment: Number(initialPayment),

        finalPayment: Number(finalPayment),

        seats: Number(seats),

        description,

        coverImage: coverImage || null,

        // -------------------------
        // Registration Control
        // -------------------------

        registrationOpensAt: registrationOpensAt
          ? new Date(registrationOpensAt)
          : null,

        registrationClosesAt: registrationClosesAt
          ? new Date(registrationClosesAt)
          : null,

        registrationOpenedManually: false,

        registrationClosedManually: false,
      },
    });

    return NextResponse.json(
      {
        message: "Trek created successfully!",
        trek,
      },
      {
        status: 201,
      }
    );
  } catch (error) {
    console.error(error);

    return NextResponse.json(
      {
        message: "Something went wrong.",
      },
      {
        status: 500,
      }
    );
  }
}

export async function GET() {
  try {
    const treks = await prisma.trek.findMany({
      orderBy: {
        createdAt: "desc",
      },
    });

    return NextResponse.json(treks);
  } catch (error) {
    console.error(error);

    return NextResponse.json(
      {
        message: "Failed to fetch treks.",
      },
      {
        status: 500,
      }
    );
  }
}