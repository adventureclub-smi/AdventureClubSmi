import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET(
  req: Request,
  {
    params,
  }: {
    params: Promise<{ registrationId: string }>;
  }
) {
  const { registrationId } = await params;

  const registration =
    await prisma.registration.findUnique({
      where: {
        id: registrationId,
      },

      include: {
        trek: true,
        user: true,
      },
    });

  if (!registration) {
    return NextResponse.json(
      {
        message: "Registration not found",
      },
      {
        status: 404,
      }
    );
  }

  return NextResponse.json(registration);
}