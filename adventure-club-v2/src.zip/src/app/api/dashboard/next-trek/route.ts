import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { prisma } from "@/lib/prisma";
import { verifyToken } from "@/lib/auth";

export async function GET() {
  try {
    const cookieStore = await cookies();

    const token = cookieStore.get("token")?.value;

    if (!token) {
      return NextResponse.json(
        { message: "Unauthorized" },
        { status: 401 }
      );
    }

    const payload = verifyToken(token);

    if (!payload) {
      return NextResponse.json(
        { message: "Invalid Session" },
        { status: 401 }
      );
    }

    const now = new Date();

    const trek = await prisma.trek.findFirst({
      where: {
        date: {
          gte: now,
        },
      },
      orderBy: {
        date: "asc",
      },
    });

    if (!trek) {
      return NextResponse.json(null);
    }

    const registration =
      await prisma.registration.findFirst({
        where: {
          trekId: trek.id,
          userId: payload.id,
        },
      });

    let registrationState:
      | "NOT_OPEN"
      | "OPEN"
      | "CLOSED" = "OPEN";

    // Manual close has highest priority
    if (trek.registrationClosedManually) {
      registrationState = "CLOSED";
    }

    // Manual open overrides automatic opening
    else if (trek.registrationOpenedManually) {
      registrationState = "OPEN";
    }

    // Automatic opening
    else if (
      trek.registrationOpensAt &&
      now < trek.registrationOpensAt
    ) {
      registrationState = "NOT_OPEN";
    }

    // Automatic closing
    else if (
      trek.registrationClosesAt &&
      now > trek.registrationClosesAt
    ) {
      registrationState = "CLOSED";
    }

    return NextResponse.json({
      trek,
      registration,

      registrationState,

      serverTime: now,

      registrationOpensAt:
        trek.registrationOpensAt,

      registrationClosesAt:
        trek.registrationClosesAt,
    });
  } catch (error) {
    console.error(error);

    return NextResponse.json(
      {
        message: "Server Error",
      },
      {
        status: 500,
      }
    );
  }
}