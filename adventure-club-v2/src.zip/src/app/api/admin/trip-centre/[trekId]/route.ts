import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";

export async function GET(
  req: Request,
  {
    params,
  }: {
    params: Promise<{ trekId: string }>;
  }
) {
  const { trekId } = await params;

  const trek = await prisma.trek.findUnique({
    where: {
      id: trekId,
    },
  });

  if (!trek) {
    return NextResponse.json(
      {
        message: "Trek not found",
      },
      {
        status: 404,
      }
    );
  }

  return NextResponse.json(trek);
}

export async function PUT(
  req: Request,
  {
    params,
  }: {
    params: Promise<{ trekId: string }>;
  }
) {
  const { trekId } = await params;

  const body = await req.json();

  const trek = await prisma.trek.update({
    where: {
      id: trekId,
    },

    data: {
      meetingPoint: body.meetingPoint,

      meetingTime: body.meetingTime
        ? new Date(body.meetingTime)
        : null,

      transportDetails:
        body.transportDetails,

      leaderMessage:
        body.leaderMessage,

      weatherNote:
        body.weatherNote,

      reportingInstructions:
        body.reportingInstructions,

      emergencyNumber:
        body.emergencyNumber,

      whatsappGroupLink:
        body.whatsappGroupLink,

      requiredItems:
        body.requiredItems,

      optionalItems:
        body.optionalItems,
    },
  });

  return NextResponse.json(trek);
}