import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function POST(req: NextRequest) {
  const body = await req.json();

  await prisma.registration.update({
    where: {
      id: body.registrationId,
    },

    data: {
      attendanceMarked: body.attended,

      attendanceMarkedAt: body.attended
        ? new Date()
        : null,
    },
  });

  return NextResponse.json({
    success: true,
  });
}