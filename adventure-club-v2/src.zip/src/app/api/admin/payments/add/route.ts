import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function POST(req: NextRequest) {
  try {
    const { registrationId } = await req.json();

    await prisma.registration.update({
      where: {
        id: registrationId,
      },
      data: {
        paymentPortal: true,
      },
    });

    return NextResponse.json({
      success: true,
    });
  } catch (error) {
    console.error(error);

    return NextResponse.json(
      {
        message: "Failed to add participant to payment portal.",
      },
      {
        status: 500,
      }
    );
  }
}