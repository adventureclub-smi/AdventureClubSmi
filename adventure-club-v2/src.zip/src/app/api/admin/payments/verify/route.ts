import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { PaymentStatus } from "@prisma/client";

export async function POST(req: NextRequest) {
  try {
    const { registrationId, verified } = await req.json();

    const payment = await prisma.payment.findFirst({
      where: {
        registrationId,
        type: "INITIAL",
      },
      orderBy: {
        createdAt: "desc",
      },
    });

    if (!payment) {
      return NextResponse.json(
        {
          message: "Payment not found",
        },
        {
          status: 404,
        }
      );
    }

    await prisma.payment.update({
      where: {
        id: payment.id,
      },
      data: {
        status: verified
          ? PaymentStatus.PAID
          : PaymentStatus.PENDING,
      },
    });

    await prisma.registration.update({
      where: {
        id: registrationId,
      },
      data: {
        initialPaymentPaid: verified,
        offlinePaymentVerified: verified,
        initialPaymentPaidAt: verified
          ? new Date()
          : null,
      },
    });

    return NextResponse.json({
      success: true,
    });
  } catch (err) {
    console.error(err);

    return NextResponse.json(
      {
        message: "Verification failed",
      },
      {
        status: 500,
      }
    );
  }
}