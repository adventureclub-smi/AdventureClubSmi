import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import {
  PaymentMethod,
  PaymentStatus,
  PaymentType,
} from "@prisma/client";

export async function POST(req: NextRequest) {
  try {
    const {
      registrationId,
      method,
      amount,
      reference,
      recordedBy,
      type,
    } = await req.json();

    const registration =
      await prisma.registration.findUnique({
        where: {
          id: registrationId,
        },
      });

    if (!registration) {
      return NextResponse.json(
        {
          message:
            "Registration not found.",
        },
        {
          status: 404,
        }
      );
    }

    const payment =
      await prisma.payment.create({
        data: {
          registrationId,

          type:
            type === "FINAL"
              ? PaymentType.FINAL
              : PaymentType.INITIAL,

          amount,

          status:
            PaymentStatus.PAID,

          paymentMethod:
            method === "UPI"
              ? PaymentMethod.UPI
              : method ===
                "BANK_TRANSFER"
              ? PaymentMethod.BANK_TRANSFER
              : PaymentMethod.CASH,

          verifiedBy: recordedBy,

          paidAt: new Date(),

          reference,
        },
      });

    await prisma.registration.update({
  where: {
    id: registrationId,
  },

  data: {
    paymentMethod: method,
    paymentReference: reference,
    paymentAmount: Number(amount),

    paymentRecordedAt: new Date(),
    paymentRecordedBy: recordedBy,

    offlinePaymentCreated: true,
    offlinePaymentVerified: true,

    ...(type === "FINAL"
      ? {
          finalPaymentPaid: true,
          finalPaymentPaidAt: new Date(),
        }
      : {
          initialPaymentPaid: true,
          initialPaymentPaidAt: new Date(),
        }),
  },
});

    return NextResponse.json(
      payment
    );
  } catch (err) {
    console.error(err);

    return NextResponse.json(
      {
        message:
          "Failed to record payment.",
      },
      {
        status: 500,
      }
    );
  }
}