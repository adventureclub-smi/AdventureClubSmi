import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET() {
  try {
    const [
      users,
      treks,
      attendance,
      registrations,
    ] = await Promise.all([
      prisma.user.count(),

      prisma.trek.count(),

      prisma.registration.count({
        where: {
          attendanceMarked: true,
        },
      }),

      prisma.registration.count(),
    ]);

    return NextResponse.json({
      users,
      treks,
      attendance,
      registrations,
    });
  } catch (error) {
    console.error(error);

    return NextResponse.json(
      {
        message: "Server Error",
      },
      {
        status: 500,
      }
    );
  }
}