import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { cookies } from "next/headers";
import { verifyToken } from "@/lib/auth";

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);

    const trekId = searchParams.get("trekId");

    if (!trekId) {
      return NextResponse.json([]);
    }

    const registrations = await prisma.registration.findMany({
      where: {
        trekId,
      },
      include: {
        user: true,
      },
      orderBy: {
        createdAt: "asc",
      },
    });

    return NextResponse.json(registrations);
  } catch (error) {
    console.error(error);

    return NextResponse.json(
      {
        message: "Failed to fetch registrations.",
      },
      {
        status: 500,
      }
    );
  }
}

export async function POST(req: Request) {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get("token")?.value;

    if (!token) {
      return NextResponse.json(
        {
          message: "Please login first.",
        },
        {
          status: 401,
        }
      );
    }

    const payload = verifyToken(token);

    if (!payload) {
      return NextResponse.json(
        {
          message: "Invalid session.",
        },
        {
          status: 401,
        }
      );
    }

    const { trekId } = await req.json();

    const user = await prisma.user.findUnique({
      where: {
        id: payload.id,
      },
    });

    if (!user) {
      return NextResponse.json(
        {
          message: "User not found.",
        },
        {
          status: 404,
        }
      );
    }

    const trek = await prisma.trek.findUnique({
      where: {
        id: trekId,
      },
    });

    if (!trek) {
      return NextResponse.json(
        {
          message: "Trek not found.",
        },
        {
          status: 404,
        }
      );
    }

    const count = await prisma.registration.count();

const registrationNumber = `REG${new Date().getFullYear()}-${String(
  count + 1
).padStart(4, "0")}`;

const registration = await prisma.registration.create({
  data: {
    registrationNumber,
    trekId,
    userId: user.id,
  },
});

    return NextResponse.json({
      message: "Registration successful!",
      registration,
    });
  } catch (error: any) {
    console.error(error);

    // Duplicate registration
    if (error.code === "P2002") {
      return NextResponse.json(
        {
          message: "Already registered.",
        },
        {
          status: 400,
        }
      );
    }

    return NextResponse.json(
      {
        message: "Server Error",
      },
      {
        status: 500,
      }
    );
  }
}