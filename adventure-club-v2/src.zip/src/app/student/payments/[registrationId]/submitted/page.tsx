import styles from "./page.module.scss";
import Link from "next/link";

export default function PaymentSubmittedPage() {
  return (
    <div className={styles.container}>
      <div className={styles.card}>

        <div className={styles.icon}>
          🎉
        </div>

        <h1>
          Payment Submitted
        </h1>

        <p>
          Your payment proof has been
          submitted successfully.
        </p>

        <div className={styles.status}>

          <h3>
            ⏳ Waiting for Verification
          </h3>

          <p>
            The Adventure Club will verify
            your payment shortly.
          </p>

        </div>

        <Link
  href="/dashboard"
  className={styles.button}
>
  Return to Dashboard
</Link>
      </div>
    </div>
  );
}