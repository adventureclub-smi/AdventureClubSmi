import StudentPaymentPage from "@/components/student/payments/StudentPaymentPage";

export default async function Page({
  params,
}: {
  params: Promise<{ registrationId: string }>;
}) {
  const { registrationId } =
    await params;

  return (
    <StudentPaymentPage
      registrationId={registrationId}
    />
  );
}