import PaymentProofPage from "@/components/student/payments/PaymentProofPage";

export default async function Page({
  params,
}: {
  params: Promise<{ registrationId: string }>;
}) {
  const { registrationId } =
    await params;

  return (
    <PaymentProofPage
      registrationId={registrationId}
    />
  );
}