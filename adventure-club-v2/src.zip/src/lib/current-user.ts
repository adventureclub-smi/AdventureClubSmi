import { cookies } from "next/headers";
import { prisma } from "@/lib/prisma";
import { verifyToken } from "@/lib/auth";

export async function getCurrentUser() {
  const cookieStore = await cookies();

  const token = cookieStore.get("token")?.value;

  console.log("TOKEN:", token);

  if (!token) {
    return null;
  }

  const payload = verifyToken(token);

  console.log("PAYLOAD:", payload);

  if (!payload) {
    return null;
  }

  const user = await prisma.user.findUnique({
    where: {
      id: payload.id,
    },
  });

  console.log("USER:", user);

  return user;
}