"use client";

import AdminSidebar from "./AdminSidebar";
import AdminWelcome from "./AdminWelcome";
import AdminStats from "./AdminStats";
import RecentRegistrations from "./RecentRegistrations";
import UpcomingTreks from "./UpcomingTreks";
import ActiveTrekCard from "./ActiveTrekCard";


import styles from "./AdminDashboard.module.scss";

export default function AdminDashboard() {
  return (
    <div className={styles.dashboard}>
      <AdminSidebar />

      <main className={styles.main}>
        <AdminWelcome />

        <AdminStats />
        <ActiveTrekCard />

        <div className={styles.grid}>
          <RecentRegistrations />

          <UpcomingTreks />
        </div>
      </main>
    </div>
  );
}