"use client";

import { useEffect, useState } from "react";
import styles from "./ActiveTrekCard.module.scss";
import Link from "next/link";

export default function ActiveTrekCard() {
  const [trek, setTrek] = useState<any>(null);

  useEffect(() => {
    fetch("/api/admin/active-trek")
      .then((res) => res.json())
      .then(setTrek);
  }, []);

  if (!trek) {
    return (
      <div className={styles.empty}>
        No Upcoming Trek
      </div>
    );
  }

  return (
    <div className={styles.card}>
      <img
        src={
          trek.coverImage ||
          "/images/default-trek.jpg"
        }
        alt={trek.title}
      />

      <div className={styles.info}>
        <small>ACTIVE TREK</small>

        <h2>{trek.title}</h2>

        <p>📍 {trek.destination}</p>

        <p>
          📅{" "}
          {new Date(
            trek.date
          ).toLocaleDateString()}
        </p>

        <div className={styles.stats}>
          <div>
            <strong>
              {trek.registered}
            </strong>

            <span>Registered</span>
          </div>

          <div>
            <strong>
              {trek.approved}
            </strong>

            <span>Approved</span>
          </div>

          <div>
            <strong>
              {trek.initialPaid}
            </strong>

            <span>Initial Paid</span>
          </div>

          <div>
            <strong>
              {trek.bondForms}
            </strong>

            <span>Bond Forms</span>
          </div>

          <div>
            <strong>
              {trek.attendance}
            </strong>

            <span>Attendance</span>
          </div>
        </div>

        <Link href={`/admin/treks/${trek.id}`}>
          <button>
            Manage Trek →
          </button>
        </Link>
      </div>
    </div>
  );
}