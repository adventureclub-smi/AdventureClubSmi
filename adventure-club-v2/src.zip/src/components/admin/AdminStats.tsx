"use client";

import { useEffect, useState } from "react";
import styles from "./AdminStats.module.scss";

export default function AdminStats() {
  const [stats, setStats] = useState({
    users: 0,
    treks: 0,
    attendance: 0,
    registrations: 0,
  });

  useEffect(() => {
    fetch("/api/admin/dashboard")
      .then((res) => res.json())
      .then(setStats);
  }, []);

  return (
    <div className={styles.grid}>
      <div className={styles.card}>
        <h2>{stats.users}</h2>
        <p>Total Accounts</p>
      </div>

      <div className={styles.card}>
        <h2>{stats.treks}</h2>
        <p>Total Treks</p>
      </div>

      <div className={styles.card}>
        <h2>{stats.attendance}</h2>
        <p>Total Participants</p>
      </div>

      <div className={styles.card}>
        <h2>{stats.registrations}</h2>
        <p>Total Registrations</p>
      </div>
    </div>
  );
}