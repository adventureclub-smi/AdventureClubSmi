"use client";

import { useRef, useState } from "react";
import { useRouter } from "next/navigation";
import styles from "./CreateTrekForm.module.scss";

export default function CreateTrekForm() {
  const router = useRouter();

  const fileInputRef = useRef<HTMLInputElement>(null);

  const [loading, setLoading] = useState(false);

  const [selectedImage, setSelectedImage] =
    useState<File | null>(null);

  const [preview, setPreview] = useState("");

  const [form, setForm] = useState({
    title: "",
    destination: "",
    trailType: "",
    difficulty: "",
    altitude: "",
    duration: "",
    distance: "",
    trekDay: "",
    date: "",
    price: "",
    initialPayment: "",
    finalPayment: "",
    seats: "",
    description: "",
    registrationOpensAt: "",

registrationClosesAt: "",
  });

  function handleChange(
    e: React.ChangeEvent<
      HTMLInputElement |
      HTMLTextAreaElement |
      HTMLSelectElement
    >
  ) {
    setForm({
      ...form,
      [e.target.name]: e.target.value,
    });
  }

  function handleImageChange(
    e: React.ChangeEvent<HTMLInputElement>
  ) {
    const file = e.target.files?.[0];

    if (!file) return;

    if (!file.type.startsWith("image/")) {
      alert("Please select an image.");
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      alert("Maximum image size is 5MB.");
      return;
    }

    setSelectedImage(file);

    setPreview(URL.createObjectURL(file));
  }

  async function handleSubmit(
    e: React.FormEvent
  ) {
    e.preventDefault();

    setLoading(true);

    let coverImage = "";

    // Upload image first
    if (selectedImage) {
      const imageData = new FormData();

      imageData.append(
        "file",
        selectedImage
      );

      const uploadRes = await fetch(
        "/api/upload",
        {
          method: "POST",
          body: imageData,
        }
      );

      const upload = await uploadRes.json();

      if (!uploadRes.ok) {
        alert(upload.message);

        setLoading(false);

        return;
      }

      coverImage = upload.url;
    }

    const res = await fetch("/api/treks", {
      method: "POST",
      headers: {
        "Content-Type":
          "application/json",
      },
      body: JSON.stringify({
        ...form,

        coverImage,

        price: Number(form.price),

        initialPayment: Number(
          form.initialPayment
        ),

        finalPayment: Number(
          form.finalPayment
        ),

        seats: Number(form.seats),
      }),
    });

    const data = await res.json();

    setLoading(false);

    if (!res.ok) {
      alert(data.message);
      return;
    }

    alert("Trek Created Successfully!");

    router.push("/admin/treks");

    router.refresh();
  }

  return (
    <form
      className={styles.form}
      onSubmit={handleSubmit}
    >
      <h1>Create New Trek</h1>

      {/* IMAGE */}

      <div className={styles.imageSection}>
        <label>
          Trek Cover Image
        </label>

        <input
          hidden
          type="file"
          ref={fileInputRef}
          accept="image/*"
          onChange={handleImageChange}
        />

        <div
          className={styles.uploadBox}
          onClick={() =>
            fileInputRef.current?.click()
          }
        >
          {preview ? (
            <img
              src={preview}
              alt="Preview"
              className={
                styles.preview
              }
            />
          ) : (
            <>
              <div
                className={
                  styles.uploadIcon
                }
              >
                📷
              </div>

              <h3>
                Upload Trek Cover
              </h3>

              <p>
                Click to upload
              </p>

              <small>
                JPG • PNG • WEBP
              </small>
            </>
          )}
        </div>

        {selectedImage && (
          <button
            type="button"
            className={
              styles.removeImage
            }
            onClick={() => {
              setSelectedImage(null);
              setPreview("");
            }}
          >
            Remove Image
          </button>
        )}
      </div>

      {/* TREK DETAILS */}

      <input
        name="title"
        placeholder="Trek Title"
        value={form.title}
        onChange={handleChange}
        required
      />

      <input
        name="destination"
        placeholder="Destination"
        value={form.destination}
        onChange={handleChange}
        required
      />

            <select
        name="trailType"
        value={form.trailType}
        onChange={handleChange}
        required
      >
        <option value="">Trail Type</option>
        <option>Out & Back</option>
        <option>Loop</option>
        <option>Point to Point</option>
        <option>Circuit</option>
      </select>

      <select
        name="difficulty"
        value={form.difficulty}
        onChange={handleChange}
        required
      >
        <option value="">Difficulty</option>
        <option>Easy</option>
        <option>Moderate</option>
        <option>Hard</option>
        <option>Extreme</option>
      </select>

      <input
        name="altitude"
        placeholder="Altitude (e.g. 1450 m)"
        value={form.altitude}
        onChange={handleChange}
        required
      />

      <input
        name="duration"
        placeholder="Duration (e.g. 1 Day / 8 Hours)"
        value={form.duration}
        onChange={handleChange}
        required
      />

      <input
        name="distance"
        placeholder="Distance (e.g. 16 km)"
        value={form.distance}
        onChange={handleChange}
        required
      />

      <select
        name="trekDay"
        value={form.trekDay}
        onChange={handleChange}
        required
      >
        <option value="">Day of Trek</option>
        <option>Monday</option>
        <option>Tuesday</option>
        <option>Wednesday</option>
        <option>Thursday</option>
        <option>Friday</option>
        <option>Saturday</option>
        <option>Sunday</option>
      </select>

      <input
        type="date"
        name="date"
        value={form.date}
        onChange={handleChange}
        required
      />

      <input
  type="datetime-local"
  name="registrationOpensAt"
  value={form.registrationOpensAt}
  onChange={handleChange}
/>

<input
  type="datetime-local"
  name="registrationClosesAt"
  value={form.registrationClosesAt}
  onChange={handleChange}
/>

      <input
        type="number"
        name="price"
        placeholder="Total Trek Cost"
        value={form.price}
        onChange={handleChange}
        required
      />

      <input
        type="number"
        name="initialPayment"
        placeholder="Initial Payment"
        value={form.initialPayment}
        onChange={handleChange}
        required
      />

      <input
        type="number"
        name="finalPayment"
        placeholder="Final Payment"
        value={form.finalPayment}
        onChange={handleChange}
        required
      />

      <input
        type="number"
        name="seats"
        placeholder="Total Seats"
        value={form.seats}
        onChange={handleChange}
        required
      />

      <textarea
        name="description"
        placeholder="Trek Description"
        rows={6}
        value={form.description}
        onChange={handleChange}
        required
      />

      <button
        type="submit"
        disabled={loading}
      >
        {loading
          ? "Creating Trek..."
          : "Create Trek"}
      </button>
    </form>
  );
}