"use client";

import { useEffect, useState } from "react";
import styles from "./TripCentreEditor.module.scss";

export default function TripCentreEditor({
  trekId,
}: {
  trekId: string;
}) {
  const [loading, setLoading] = useState(false);

  const [form, setForm] = useState({
    meetingPoint: "",
    meetingTime: "",
    transportDetails: "",
    weatherNote: "",
    whatsappGroupLink: "",
    emergencyNumber: "",
    itinerary: "",
    leaderMessage: "",
    reportingInstructions: "",
    requiredItems: "",
    optionalItems: "",
  });

  useEffect(() => {
    fetch(`/api/admin/trip-centre/${trekId}`)
      .then((res) => res.json())
      .then((data) =>
        setForm({
          meetingPoint:
            data.meetingPoint || "",

          meetingTime:
            data.meetingTime
              ? data.meetingTime.slice(0, 16)
              : "",

          transportDetails:
            data.transportDetails || "",

          weatherNote:
            data.weatherNote || "",

          whatsappGroupLink:
            data.whatsappGroupLink || "",

          emergencyNumber:
            data.emergencyNumber || "",

          itinerary:
            data.itinerary || "",

          leaderMessage:
            data.leaderMessage || "",

          reportingInstructions:
            data.reportingInstructions || "",

          requiredItems:
            data.requiredItems?.join("\n") ||
            "",

          optionalItems:
            data.optionalItems?.join("\n") ||
            "",
        })
      );
  }, [trekId]);

  function handleChange(
    e: React.ChangeEvent<
      HTMLInputElement | HTMLTextAreaElement
    >
  ) {
    setForm({
      ...form,
      [e.target.name]: e.target.value,
    });
  }

  async function handleSubmit(
    e: React.FormEvent
  ) {
    e.preventDefault();

    setLoading(true);

    const res = await fetch(
      `/api/admin/trip-centre/${trekId}`,
      {
        method: "PUT",

        headers: {
          "Content-Type":
            "application/json",
        },

        body: JSON.stringify({
          ...form,

          requiredItems:
            form.requiredItems
              .split("\n")
              .filter(Boolean),

          optionalItems:
            form.optionalItems
              .split("\n")
              .filter(Boolean),
        }),
      }
    );

    setLoading(false);

    if (res.ok) {
      alert("Trip Centre Updated!");
    } else {
      alert("Failed to update.");
    }
  }

  return (
    <form
      className={styles.form}
      onSubmit={handleSubmit}
    >
      <h1>Trip Centre Editor</h1>

      <input
        name="meetingPoint"
        placeholder="Meeting Point"
        value={form.meetingPoint}
        onChange={handleChange}
      />

      <input
        type="datetime-local"
        name="meetingTime"
        value={form.meetingTime}
        onChange={handleChange}
      />

      <input
        name="transportDetails"
        placeholder="Transport Details"
        value={form.transportDetails}
        onChange={handleChange}
      />

      <input
        name="weatherNote"
        placeholder="Weather Note"
        value={form.weatherNote}
        onChange={handleChange}
      />

      <input
        name="emergencyNumber"
        placeholder="Emergency Number"
        value={form.emergencyNumber}
        onChange={handleChange}
      />

      <input
        name="whatsappGroupLink"
        placeholder="WhatsApp Group Link"
        value={form.whatsappGroupLink}
        onChange={handleChange}
      />

      <textarea
        rows={8}
        name="itinerary"
        placeholder="Itinerary"
        value={form.itinerary}
        onChange={handleChange}
      />

      <textarea
        rows={5}
        name="leaderMessage"
        placeholder="Leader Message"
        value={form.leaderMessage}
        onChange={handleChange}
      />

      <textarea
        rows={6}
        name="reportingInstructions"
        placeholder="Reporting Instructions"
        value={form.reportingInstructions}
        onChange={handleChange}
      />

      <textarea
        rows={8}
        name="requiredItems"
        placeholder="Required Items (one per line)"
        value={form.requiredItems}
        onChange={handleChange}
      />

      <textarea
        rows={8}
        name="optionalItems"
        placeholder="Optional Items (one per line)"
        value={form.optionalItems}
        onChange={handleChange}
      />

      <button
        disabled={loading}
      >
        {loading
          ? "Saving..."
          : "Save Trip Centre"}
      </button>
    </form>
  );
}