"use client";

import { useEffect, useState } from "react";
import styles from "./MembersTable.module.scss";
import Link from "next/link";

interface Member {
  id: string;
  clubId: string;
  fullName: string;
  email: string;
  phoneNumber: string;
  year: string;
  department: string;
  membershipStatus: string;
  clubRole: string;
}

export default function MembersTable() {
  const [members, setMembers] = useState<Member[]>([]);
  const [search, setSearch] = useState("");

  useEffect(() => {
    fetch("/api/admin/members")
      .then((res) => res.json())
      .then(setMembers);
  }, []);

  const filtered = members.filter((member) =>
    `${member.fullName} ${member.clubId} ${member.department}`
      .toLowerCase()
      .includes(search.toLowerCase())
  );

  async function approve(id: string) {
    await fetch(`/api/admin/members/${id}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        membershipStatus: "ACTIVE",
        clubRole: "Member",
      }),
    });

    setMembers((prev) =>
      prev.map((member) =>
        member.id === id
          ? {
              ...member,
              membershipStatus: "ACTIVE",
            }
          : member
      )
    );
  }

  return (
    <div className={styles.container}>
      <div className={styles.top}>
        <h1>Members</h1>

        <input
          placeholder="Search members..."
          value={search}
          onChange={(e) =>
            setSearch(e.target.value)
          }
        />
      </div>

      <table className={styles.table}>
        <thead>
          <tr>
            <th>Club ID</th>
            <th>Name</th>
            <th>Year</th>
            <th>Department</th>
            <th>Status</th>
            <th>Role</th>
            <th></th>
          </tr>
        </thead>

        <tbody>
          {filtered.map((member) => (
            <tr key={member.id}>
              <td>{member.clubId}</td>

              <td>
                <strong>
                  {member.fullName}
                </strong>

                <p>{member.email}</p>
              </td>

              <td>{member.year}</td>

              <td>
                {member.department}
              </td>

              <td>
                <span
                  className={
                    member.membershipStatus ===
                    "ACTIVE"
                      ? styles.active
                      : styles.pending
                  }
                >
                  {
                    member.membershipStatus
                  }
                </span>
              </td>

              <td>{member.clubRole}</td>

              <td>
                {member.membershipStatus ===
                "PENDING" ? (
                  <button
                    onClick={() =>
                      approve(member.id)
                    }
                  >
                    Approve
                  </button>
                ) : (
                  <Link href={`/admin/members/${member.id}`}>
  <button>
    Manage
  </button>
</Link>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}