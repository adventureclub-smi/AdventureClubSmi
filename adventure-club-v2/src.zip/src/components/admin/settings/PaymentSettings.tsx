"use client";

import { useEffect, useState } from "react";
import styles from "./PaymentSettings.module.scss";

export default function PaymentSettings() {
  const [clubName, setClubName] = useState("");
  const [receiverName, setReceiverName] =
    useState("");
  const [upiId, setUpiId] = useState("");
  const [supportPhone, setSupportPhone] =
    useState("");

  const [loading, setLoading] =
    useState(true);

  const [saving, setSaving] =
    useState(false);

  useEffect(() => {
    loadSettings();
  }, []);

  async function loadSettings() {
    try {
      const res = await fetch(
        "/api/admin/settings/payment"
      );

      const data = await res.json();

      if (data) {
        setClubName(data.clubName || "");
        setReceiverName(
          data.receiverName || ""
        );
        setUpiId(data.upiId || "");
        setSupportPhone(
          data.supportPhone || ""
        );
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }

  async function save() {
    setSaving(true);

    try {
      const res = await fetch(
        "/api/admin/settings/payment",
        {
          method: "POST",

          headers: {
            "Content-Type":
              "application/json",
          },

          body: JSON.stringify({
            clubName,
            receiverName,
            upiId,
            supportPhone,
          }),
        }
      );

      if (!res.ok) {
        alert("Failed to save.");
        return;
      }

      alert(
        "Payment Settings Saved!"
      );
    } catch (err) {
      console.error(err);
      alert("Something went wrong.");
    }

    setSaving(false);
  }

  if (loading) {
    return <p>Loading...</p>;
  }

  return (
    <div className={styles.container}>

      <h1>
        Payment Settings
      </h1>

      <p>
        These settings will be
        used for every payment
        page automatically.
      </p>

      <div className={styles.form}>

        <label>
          Club Name
        </label>

        <input
          value={clubName}
          onChange={(e) =>
            setClubName(
              e.target.value
            )
          }
        />

        <label>
          Receiver Name
        </label>

        <input
          value={receiverName}
          onChange={(e) =>
            setReceiverName(
              e.target.value
            )
          }
        />

        <label>
          UPI ID
        </label>

        <input
          placeholder="club@oksbi"
          value={upiId}
          onChange={(e) =>
            setUpiId(
              e.target.value
            )
          }
        />

        <label>
          Support Phone
        </label>

        <input
          value={supportPhone}
          onChange={(e) =>
            setSupportPhone(
              e.target.value
            )
          }
        />

        <button
          onClick={save}
          disabled={saving}
        >
          {saving
            ? "Saving..."
            : "Save Settings"}
        </button>

      </div>

    </div>
  );
}