"use client";

import Link from "next/link";
import Image from "next/image";

import {
  LayoutDashboard,
  Mountain,
  Users,
  ClipboardList,
  ImageIcon,
  Settings,
  LogOut,
} from "lucide-react";

import styles from "./AdminSidebar.module.scss";

export default function AdminSidebar() {
  return (
    <aside className={styles.sidebar}>
      <div>
        {/* Logo */}

        <div className={styles.logo}>
          <Image
            src="/logo/logo-white.png"
            alt="Adventure Club"
            width={60}
            height={60}
          />

          <div className={styles.logoText}>
            <h2>Adventure Club</h2>
            <span>Admin Panel</span>
          </div>
        </div>

        {/* Navigation */}

        <nav className={styles.nav}>
          <Link href="/admin" className={styles.link}>
            <LayoutDashboard size={20} />
            Dashboard
          </Link>

          <Link href="/admin/create-trek" className={styles.link}>
            <Mountain size={20} />
            Create Trek
          </Link>

          <Link href="/admin/treks" className={styles.link}>
  <Mountain size={20} />
  Manage Treks
</Link>

          <Link href="/admin/members" className={styles.link}>
            <Users size={20} />
            Members
          </Link>

          <Link href="/admin/registrations" className={styles.link}>
            <ClipboardList size={20} />
            Registrations
          </Link>

          <Link href="/admin/gallery" className={styles.link}>
            <ImageIcon size={20} />
            Gallery
          </Link>

          <Link href="/admin/settings" className={styles.link}>
            <Settings size={20} />
            Settings
          </Link>
        </nav>
      </div>

      {/* Logout */}

      <button className={styles.logout}>
        <LogOut size={20} />
        Logout
      </button>
    </aside>
  );
}