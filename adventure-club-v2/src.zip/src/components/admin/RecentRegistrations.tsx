"use client";

import { useEffect, useState } from "react";
import styles from "./RecentRegistrations.module.scss";

export default function RecentRegistrations() {
  const [registrations, setRegistrations] = useState<any[]>([]);

  useEffect(() => {
    fetch("/api/admin/recent-registrations")
      .then((res) => res.json())
      .then(setRegistrations);
  }, []);

  return (
    <div className={styles.card}>
      <div className={styles.header}>
        <h2>Recent Registrations</h2>
      </div>

      {registrations.length === 0 ? (
        <p>No registrations yet.</p>
      ) : (
        registrations.map((registration) => (
          <div
            key={registration.id}
            className={styles.row}
          >
            <div>
              <strong>
                {registration.user?.fullName ||
                  registration.guestName}
              </strong>

              <p>{registration.trek.title}</p>
            </div>

            <span>{registration.status}</span>
          </div>
        ))
      )}
    </div>
  );
}