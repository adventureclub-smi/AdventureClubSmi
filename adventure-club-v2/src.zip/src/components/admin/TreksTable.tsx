"use client";

import { useEffect, useState } from "react";
import styles from "./TreksTable.module.scss";
import Link from "next/link";

type Trek = {
  id: string;
  title: string;
  destination: string;
  difficulty: string;
  date: string;
  price: number;
  seats: number;
  description: string;
};

export default function TreksTable() {
  const [treks, setTreks] = useState<Trek[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchTreks();
  }, []);

  async function fetchTreks() {
  try {
    const res = await fetch("/api/treks");
    const data = await res.json();
console.log(data);
console.log(Array.isArray(data));

    console.log("Treks API:", data);

    if (Array.isArray(data)) {
      setTreks(data);
    } else if (Array.isArray(data.treks)) {
      setTreks(data.treks);
    } else if (Array.isArray(data.data)) {
      setTreks(data.data);
    } else {
      console.error("Unexpected API response:", data);
      setTreks([]);
    }
  } catch (error) {
    console.error("Failed to fetch treks:", error);
    setTreks([]);
  } finally {
    setLoading(false);
  }
}

  if (loading) {
    return (
      <div className={styles.container}>
        <h1 className={styles.title}>Manage Treks</h1>
        <p>Loading treks...</p>
      </div>
    );
  }
  async function deleteTrek(id: string) {
  const confirmDelete = confirm(
    "Are you sure you want to delete this trek?"
  );

  if (!confirmDelete) return;

  try {
    const res = await fetch(`/api/treks/${id}`, {
      method: "DELETE",
    });

    const data = await res.json();

    if (!res.ok) {
      alert(data.message);
      return;
    }

    alert("Trek deleted!");

    fetchTreks();
  } catch (error) {
    console.error(error);
    alert("Something went wrong.");
  }
}

  return (
    <div className={styles.container}>
      <h1 className={styles.title}>Manage Treks</h1>

      {treks.length === 0 ? (
        <p>No treks available.</p>
      ) : (
        <div className={styles.grid}>
          {treks.map((trek) => (
            <div key={trek.id} className={styles.card}>
              <h2>{trek.title}</h2>

              <div className={styles.info}>
                <span>📍 {trek.destination}</span>
                <span>🥾 {trek.difficulty}</span>
                <span>
                  📅 {new Date(trek.date).toLocaleDateString()}
                </span>
                <span>💰 ₹{trek.price}</span>
                <span>👥 {trek.seats} Seats</span>
              </div>

              <p className={styles.description}>
                {trek.description}
              </p>

              <div className={styles.buttons}>
                <Link href={`/admin/treks/${trek.id}`}>
  <button className={styles.edit}>
    Manage Trek
  </button>
</Link>

                <button
  className={styles.delete}
  onClick={() => deleteTrek(trek.id)}
>
  Delete
</button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}