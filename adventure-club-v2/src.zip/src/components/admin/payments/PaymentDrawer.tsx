"use client";

import { useState } from "react";
import styles from "./PaymentDrawer.module.scss";

interface Props {
  registration: any;
  onClose: () => void;
  refresh: () => void;
}

export default function PaymentDrawer({
  registration,
  onClose,
  refresh,
}: Props) {
  const [loading, setLoading] = useState(false);

  const payment = registration.payments?.[0];

  const [method, setMethod] = useState("Cash");
  const [reference, setReference] = useState("");
  const [amount, setAmount] = useState(
    registration.paymentAmount || 0
  );
  const [recordedBy, setRecordedBy] =
    useState("Admin");

  async function recordOfflinePayment() {
    setLoading(true);

    try {
      const res = await fetch(
        "/api/admin/payments/offline",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            registrationId: registration.id,
            method,
            reference,
            amount,
            recordedBy,
          }),
        }
      );

      const data = await res.json();

      if (!res.ok) {
        alert(data.message);
        return;
      }

      alert("Offline payment recorded.");

      refresh();
      onClose();
    } catch (err) {
      console.error(err);
      alert("Something went wrong.");
    }

    setLoading(false);
  }

  async function verify() {
    await fetch("/api/admin/payments/verify", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        registrationId: registration.id,
        verified: !registration.initialPaymentPaid,
      }),
    });

    refresh();
    onClose();
  }

  async function unlock() {
    await fetch("/api/admin/payments/unlock", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        registrationId: registration.id,
        unlock:
          !registration.finalPaymentUnlocked,
      }),
    });

    refresh();
    onClose();
  }

  return (
    <div className={styles.overlay}>
      <div className={styles.drawer}>
        <button
          className={styles.close}
          onClick={onClose}
        >
          ✕
        </button>

        <h2>
          {registration.user?.fullName ??
            registration.guestName}
        </h2>

        <p>{registration.user?.clubId}</p>

        {/* Participant */}

        <div className={styles.card}>
          <h3>Participant Details</h3>

          <div className={styles.item}>
            <span>Name</span>
            <strong>
              {registration.user?.fullName ??
                registration.guestName}
            </strong>
          </div>

          <div className={styles.item}>
            <span>Club ID</span>
            <strong>
              {registration.user?.clubId || "-"}
            </strong>
          </div>

          <div className={styles.item}>
            <span>Email</span>
            <strong>
              {registration.user?.email || "-"}
            </strong>
          </div>

          <div className={styles.item}>
            <span>Status</span>
            <strong>{registration.status}</strong>
          </div>
        </div>

        {/* Reimbursement Details */}

<div className={styles.card}>
  <h3>Reimbursement Details</h3>

  <div className={styles.item}>
    <span>UPI ID</span>

    <strong>
      {registration.user?.upiId || "-"}
    </strong>
  </div>

  <div className={styles.item}>
    <span>UPI Phone</span>

    <strong>
      {registration.user?.upiPhone || "-"}
    </strong>
  </div>

  <small className={styles.note}>
    Latest profile details entered by the student.
    These will be used for reimbursement.
  </small>
</div>

        {/* Initial Payment */}

        <div className={styles.card}>
          <h3>Initial Payment</h3>

          <div className={styles.item}>
            <span>Status</span>

            <strong>
              {registration.initialPaymentPaid
                ? "🟢 Verified"
                : registration.offlinePaymentCreated
                ? "🟡 Waiting Verification"
                : "🔴 Pending"}
            </strong>
          </div>

          <div className={styles.item}>
            <span>Recorded Amount</span>

            <strong>
              ₹{registration.paymentAmount ?? payment?.amount ?? 0}
            </strong>
          </div>

          <div className={styles.item}>
            <span>UTR / Reference</span>

            <strong>
              {payment?.reference ||
                registration.paymentReference ||
                "-"}
            </strong>
          </div>

          <div className={styles.screenshotSection}>
  <span>Payment Screenshot</span>

  {payment?.notes ? (
    <a
      href={payment.notes}
      target="_blank"
      rel="noreferrer"
      className={styles.imageLink}
    >
      <img
        src={payment.notes}
        alt="Payment Screenshot"
        className={styles.paymentImage}
      />

      <p>Click to enlarge</p>
    </a>
  ) : (
    <div className={styles.noImage}>
      No Screenshot Uploaded
    </div>
  )}
</div>

          <div className={styles.divider}></div>

          <h4>Record Offline Payment</h4>

          <select
            value={method}
            onChange={(e) =>
              setMethod(e.target.value)
            }
            className={styles.input}
          >
            <option>Cash</option>
            <option>UPI</option>
            <option>Bank Transfer</option>
          </select>

          <input
            className={styles.input}
            placeholder="Reference Number"
            value={reference}
            onChange={(e) =>
              setReference(e.target.value)
            }
          />

          <input
            className={styles.input}
            type="number"
            placeholder="Amount"
            value={amount}
            onChange={(e) =>
              setAmount(Number(e.target.value))
            }
          />

          <input
            className={styles.input}
            placeholder="Recorded By"
            value={recordedBy}
            onChange={(e) =>
              setRecordedBy(e.target.value)
            }
          />

          <button
            className={styles.action}
            disabled={loading}
            onClick={recordOfflinePayment}
          >
            Record Offline Payment
          </button>

          {registration.offlinePaymentCreated && (
            <button
              className={styles.action}
              onClick={verify}
            >
              {registration.initialPaymentPaid
                ? "Undo Verification"
                : "Verify Initial Payment"}
            </button>
          )}
        </div>

        {/* Final Payment */}

        <div className={styles.card}>
          <h3>Final Payment</h3>

          <div className={styles.item}>
            <span>Status</span>

            <strong>
              {registration.finalPaymentPaid
                ? "🟢 Paid"
                : registration.finalPaymentUnlocked
                ? "🟡 Unlocked"
                : "🔒 Locked"}
            </strong>
          </div>

          <button
            className={styles.action}
            onClick={unlock}
          >
            {registration.finalPaymentUnlocked
              ? "Lock Final Payment"
              : "Unlock Final Payment"}
          </button>
        </div>

        {/* Timeline */}

        <div className={styles.card}>
          <h3>Timeline</h3>

          <p>✅ Registration Approved</p>

          {registration.paymentPortal && (
            <p>✅ Added to Payment Portal</p>
          )}

          {registration.offlinePaymentCreated && (
            <p>✅ Payment Submitted</p>
          )}

          {registration.initialPaymentPaid && (
            <p>✅ Payment Verified</p>
          )}

          {registration.finalPaymentUnlocked && (
            <p>✅ Final Payment Unlocked</p>
          )}

          {registration.finalPaymentPaid && (
            <p>✅ Final Payment Paid</p>
          )}
        </div>
      </div>
    </div>
  );
}