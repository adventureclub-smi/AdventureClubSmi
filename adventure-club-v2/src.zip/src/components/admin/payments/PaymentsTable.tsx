"use client";

import { useEffect, useMemo, useState } from "react";
import styles from "./PaymentsTable.module.scss";
import PaymentDrawer from "./PaymentDrawer";

type Registration = {
  id: string;
  status: string;

  initialPaymentPaid: boolean;
  finalPaymentPaid: boolean;
  finalPaymentUnlocked: boolean;

  paymentAmount: number | null;
  paymentMethod: string | null;
  paymentPortal: boolean;

  user: {
    fullName: string;
    clubId: string;
  } | null;

  guestName: string | null;
};

interface Props {
  trekId: string;
}

export default function PaymentsTable({
  trekId,
}: Props) {
  const [registrations, setRegistrations] =
    useState<Registration[]>([]);

  const [loading, setLoading] =
    useState(true);

  const [search, setSearch] =
    useState("");

  const [selected, setSelected] =
    useState<Registration | null>(null);

  useEffect(() => {
    fetchPayments();
  }, []);

  async function fetchPayments() {
    try {
      const res = await fetch(
        `/api/admin/payments/${trekId}`
      );

      const data = await res.json();

      setRegistrations(data);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  }

  const filtered = useMemo(() => {
    return registrations.filter((registration) => {
      const name =
        registration.user?.fullName ??
        registration.guestName ??
        "";

      const clubId =
        registration.user?.clubId ?? "";

      return (
        name
          .toLowerCase()
          .includes(search.toLowerCase()) ||
        clubId
          .toLowerCase()
          .includes(search.toLowerCase())
      );
    });
  }, [registrations, search]);

  const stats = useMemo(() => {
    const participants =
      registrations.length;

    const initialPaid =
      registrations.filter(
        (r) => r.initialPaymentPaid
      ).length;

    const finalPaid =
      registrations.filter(
        (r) => r.finalPaymentPaid
      ).length;

    const pending =
      registrations.filter(
        (r) => !r.initialPaymentPaid
      ).length;

    const collected =
      registrations.reduce(
        (sum, r) =>
          sum +
          (r.initialPaymentPaid
            ? r.paymentAmount ?? 0
            : 0),
        0
      );

    return {
      participants,
      initialPaid,
      finalPaid,
      pending,
      collected,
    };
  }, [registrations]);

  if (loading) {
    return (
      <div className={styles.loading}>
        Loading Payments...
      </div>
    );
  }

    return (
    <div className={styles.container}>

      <div className={styles.header}>

        <div>
          <h1>Payments</h1>
          <p>
            Manage all participant payments
          </p>
        </div>

        <input
          type="text"
          placeholder="Search participant..."
          value={search}
          onChange={(e) =>
            setSearch(e.target.value)
          }
          className={styles.search}
        />

      </div>

      <div className={styles.stats}>

        <div className={styles.statCard}>
          <h2>{stats.participants}</h2>
          <span>Participants</span>
        </div>

        <div className={styles.statCard}>
          <h2>{stats.initialPaid}</h2>
          <span>Initial Paid</span>
        </div>

        <div className={styles.statCard}>
          <h2>{stats.finalPaid}</h2>
          <span>Final Paid</span>
        </div>

        <div className={styles.statCard}>
          <h2>₹{stats.collected}</h2>
          <span>Collected</span>
        </div>

        <div className={styles.statCard}>
          <h2>{stats.pending}</h2>
          <span>Pending</span>
        </div>

      </div>

      <div className={styles.cards}>

        {filtered.length === 0 ? (

          <div className={styles.empty}>
            No participants found.
          </div>

        ) : (

          filtered.map((registration) => {

            const participant =
              registration.user?.fullName ??
              registration.guestName ??
              "Unknown Participant";

            const clubId =
              registration.user?.clubId ??
              "-";

            return (

              <div
                key={registration.id}
                className={styles.card}
              >

                <div className={styles.cardHeader}>

                  <div>

                    <h3>{participant}</h3>

                    <p>{clubId}</p>

                  </div>

                  <button
                    className={styles.manage}
                    onClick={() =>
                      setSelected(registration)
                    }
                  >
                    View Details
                  </button>

                </div>

                <div className={styles.grid}>

                                    <div className={styles.infoCard}>

                    <span>Initial Payment</span>

                    {registration.initialPaymentPaid ? (

                      <strong className={styles.success}>
                        🟢 Paid
                      </strong>

                    ) : (

                      <strong className={styles.danger}>
                        🔴 Pending
                      </strong>

                    )}

                  </div>

                  <div className={styles.infoCard}>

                    <span>Final Payment</span>

                    {registration.finalPaymentPaid ? (

                      <strong className={styles.success}>
                        🟢 Paid
                      </strong>

                    ) : registration.finalPaymentUnlocked ? (

                      <strong className={styles.warning}>
                        🟡 Unlocked
                      </strong>

                    ) : (

                      <strong className={styles.locked}>
                        🔒 Locked
                      </strong>

                    )}

                  </div>

                  <div className={styles.infoCard}>

                    <span>Method</span>

                    <strong>
                      {registration.paymentMethod ??
                        "Not Recorded"}
                    </strong>

                  </div>

                  <div className={styles.infoCard}>

                    <span>Amount</span>

                    <strong>
                      ₹
                      {registration.paymentAmount ??
                        0}
                    </strong>

                  </div>

                </div>

              </div>

            );

          })

        )}

      </div>

            {selected && (
        <PaymentDrawer
          registration={selected}
          onClose={() => setSelected(null)}
          refresh={fetchPayments}
        />
      )}
    </div>
  );
}


  