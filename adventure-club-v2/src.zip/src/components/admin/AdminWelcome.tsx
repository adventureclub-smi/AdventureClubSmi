"use client";

import Link from "next/link";
import { Plus } from "lucide-react";
import styles from "./AdminWelcome.module.scss";

export default function AdminWelcome() {
  const hour = new Date().getHours();

  let greeting = "Good Evening";

  if (hour < 12) greeting = "Good Morning";
  else if (hour < 17) greeting = "Good Afternoon";

  return (
    <div className={styles.header}>
      <div>
        <h1>
          {greeting}, <span>Admin 👋</span>
        </h1>

        <p>
          Welcome back to the Adventure Club dashboard.
        </p>
      </div>

      <Link
        href="/admin/create-trek"
        className={styles.button}
      >
        <Plus size={20} />
        <span>Create Trek</span>
      </Link>
    </div>
  );
}