"use client";

import { useEffect, useState } from "react";
import styles from "./MemberProfile.module.scss";

export default function MemberProfile({
  userId,
}: {
  userId: string;
}) {
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    fetch(`/api/admin/members/${userId}`)
      .then((res) => res.json())
      .then(setUser);
  }, [userId]);

  async function save() {
    await fetch(`/api/admin/members/${userId}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        membershipStatus: user.membershipStatus,
        clubRole: user.clubRole,
      }),
    });

    alert("Changes Saved");
  }

  if (!user) {
    return (
      <div className={styles.container}>
        Loading...
      </div>
    );
  }

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <div>
          <h1>{user.fullName}</h1>
          <p>{user.clubId}</p>
        </div>

        <button onClick={save}>
          Save Changes
        </button>
      </div>

      <div className={styles.grid}>

        {/* PERSONAL INFO */}

        <section className={styles.card}>
          <h2>Personal Information</h2>

          <p>
            <strong>Name:</strong>{" "}
            {user.fullName}
          </p>

          <p>
            <strong>Email:</strong>{" "}
            {user.email}
          </p>

          <p>
            <strong>Phone:</strong>{" "}
            {user.phoneNumber}
          </p>

          <p>
            <strong>Department:</strong>{" "}
            {user.department}
          </p>

          <p>
            <strong>Year:</strong>{" "}
            {user.year}
          </p>

          <p>
            <strong>Club ID:</strong>{" "}
            {user.clubId}
          </p>
        </section>

        {/* MEMBERSHIP */}

        <section className={styles.card}>
          <h2>Membership</h2>

          <div className={styles.fields}>

            <div>
              <label>
                Membership Status
              </label>

              <select
                value={
                  user.membershipStatus
                }
                onChange={(e) =>
                  setUser({
                    ...user,
                    membershipStatus:
                      e.target.value,
                  })
                }
              >
                <option value="PENDING">
                  Pending
                </option>

                <option value="ACTIVE">
                  Active
                </option>

                <option value="SUSPENDED">
                  Suspended
                </option>
              </select>
            </div>

            <div>
              <label>
                Club Role
              </label>

              <select
                value={user.clubRole}
                onChange={(e) =>
                  setUser({
                    ...user,
                    clubRole:
                      e.target.value,
                  })
                }
              >
                <option>
                  Member
                </option>

                <option>
                  Volunteer
                </option>

                <option>
                  Logistics Head
                </option>

                <option>
                  Marketing Head
                </option>

                <option>
                  Treasurer
                </option>

                <option>
                  Photographer
                </option>

                <option>
                  Vice President
                </option>

                <option>
                  President
                </option>
              </select>
            </div>

          </div>
        </section>

        {/* EMERGENCY */}

        <section className={styles.card}>
          <h2>Emergency Contact</h2>

          <p>
            <strong>Name:</strong>{" "}
            {user.emergencyContactName ||
              "-"}
          </p>

          <p>
            <strong>Relationship:</strong>{" "}
            {user.emergencyContactRelation ||
              "-"}
          </p>

          <p>
            <strong>Phone:</strong>{" "}
            {user.emergencyContactPhone ||
              "-"}
          </p>
        </section>

        {/* TREK HISTORY */}

        <section className={styles.card}>
          <h2>Trek History</h2>

          {user.registrations?.length ===
          0 ? (
            <p>
              No treks yet.
            </p>
          ) : (
            user.registrations.map(
              (
                registration: any
              ) => (
                <div
                  key={
                    registration.id
                  }
                  style={{
                    marginBottom:
                      "18px",
                  }}
                >
                  <strong>
                    {
                      registration
                        .trek.title
                    }
                  </strong>

                  <p>
                    Status :{" "}
                    {
                      registration.status
                    }
                  </p>
                </div>
              )
            )
          )}
        </section>

      </div>
    </div>
  );
}