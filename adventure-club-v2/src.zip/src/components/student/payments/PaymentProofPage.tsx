"use client";

import { useState } from "react";
import styles from "./PaymentProofPage.module.scss";

interface Props {
  registrationId: string;
}

export default function PaymentProofPage({
  registrationId,
}: Props) {
  const [transactionId, setTransactionId] =
    useState("");

  const [file, setFile] =
    useState<File | null>(null);

  const [loading, setLoading] =
    useState(false);

  async function submit() {
    if (!transactionId && !file) {
      alert(
        "Enter Transaction ID or upload a screenshot."
      );
      return;
    }

    setLoading(true);

    try {
      const form = new FormData();

      form.append(
        "registrationId",
        registrationId
      );

      form.append(
        "transactionId",
        transactionId
      );

      if (file) {
        form.append(
          "screenshot",
          file
        );
      }

      const res = await fetch(
        "/api/student/payment/proof",
        {
          method: "POST",
          body: form,
        }
      );

      if (!res.ok) {
        throw new Error();
      }

      window.location.href =
        `/student/payments/${registrationId}/submitted`;

    } catch {
      alert(
        "Failed to submit payment."
      );
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className={styles.container}>
      <div className={styles.card}>

        <h1>Payment Proof</h1>

        <p className={styles.subtitle}>
          Upload your payment screenshot
          or simply enter the UTR /
          Transaction ID. The club will
          verify it shortly.
        </p>

        <div className={styles.field}>
          <label>
            Transaction ID / UTR
          </label>

          <input
            type="text"
            placeholder="Enter Transaction ID"
            value={transactionId}
            onChange={(e) =>
              setTransactionId(
                e.target.value
              )
            }
          />
        </div>

        <div className={styles.upload}>
          <strong>
            OR Upload Payment Screenshot
          </strong>

          <br />
          <br />

          <input
            type="file"
            accept="image/*"
            onChange={(e) =>
              setFile(
                e.target.files?.[0] ??
                  null
              )
            }
          />

          {file && (
            <p
              style={{
                marginTop: 12,
              }}
            >
              ✅ {file.name}
            </p>
          )}
        </div>

        <button
          className={styles.submit}
          onClick={submit}
          disabled={loading}
        >
          {loading
            ? "Submitting..."
            : "Submit Payment"}
        </button>

      </div>
    </div>
  );
}