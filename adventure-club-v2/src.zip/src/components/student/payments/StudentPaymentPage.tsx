"use client";

import { useEffect, useState } from "react";
import QRCode from "qrcode";
import styles from "./StudentPaymentPage.module.scss";

interface Props {
  registrationId: string;
}

export default function StudentPaymentPage({
  registrationId,
}: Props) {
  const [registration, setRegistration] =
    useState<any>(null);

  const [settings, setSettings] =
    useState<any>(null);

  const [qrCode, setQrCode] =
    useState("");

  const [loading, setLoading] =
    useState(true);

  useEffect(() => {
    load();
  }, []);

  async function load() {
    try {
      const registrationRes = await fetch(
        `/api/student/payment/${registrationId}`
      );

      const registrationData =
        await registrationRes.json();

      const settingsRes = await fetch(
        "/api/admin/settings/payment"
      );

      const settingsData =
        await settingsRes.json();

      setRegistration(registrationData);
      setSettings(settingsData);

      const amount =
        registrationData.trek.initialPayment;

      const paymentNote =
        `${registrationData.registrationNumber} - ${
          registrationData.user?.fullName ??
          registrationData.guestName
        }`;

      const upiLink =
        `upi://pay?pa=${settingsData.upiId}` +
        `&pn=${encodeURIComponent(
          settingsData.receiverName
        )}` +
        `&mc=8299` +
        `&am=${amount}` +
        `&cu=INR` +
        `&tn=${encodeURIComponent(
          paymentNote
        )}`;

      const qr =
        await QRCode.toDataURL(
          upiLink,
          {
            width: 380,
            margin: 2,
            errorCorrectionLevel: "H",
          }
        );

      setQrCode(qr);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }

  if (
    loading ||
    !registration ||
    !settings
  ) {
    return (
      <div className={styles.loading}>
        Loading Payment...
      </div>
    );
  }

  const amount =
    registration.trek.initialPayment;

  const paymentNote =
    `${registration.registrationNumber} - ${
      registration.user?.fullName ??
      registration.guestName
    }`;

  const upiLink =
    `upi://pay?pa=${settings.upiId}` +
    `&pn=${encodeURIComponent(
      settings.receiverName
    )}` +
    `&mc=8299` +
    `&am=${amount}` +
    `&cu=INR` +
    `&tn=${encodeURIComponent(
      paymentNote
    )}`;

  function copyUpi() {
    navigator.clipboard.writeText(
      settings.upiId
    );

    alert("UPI ID copied.");
  }

  function copyNote() {
    navigator.clipboard.writeText(
      paymentNote
    );

    alert("Payment note copied.");
  }

  function fallbackUPI() {
    window.location.href = upiLink;
  }

  function openGooglePay() {
    window.location.href =
      `gpay://upi/pay?${upiLink.replace(
        "upi://pay?",
        ""
      )}`;

    setTimeout(() => {
      fallbackUPI();
    }, 1200);
  }

  function openPhonePe() {
    window.location.href =
      `phonepe://pay?${upiLink.replace(
        "upi://pay?",
        ""
      )}`;

    setTimeout(() => {
      fallbackUPI();
    }, 1200);
  }

  function openPaytm() {
    window.location.href =
      `paytmmp://pay?${upiLink.replace(
        "upi://pay?",
        ""
      )}`;

    setTimeout(() => {
      fallbackUPI();
    }, 1200);
  }

  return (
    <div className={styles.container}>
      <div className={styles.card}>

        <h1>Initial Payment</h1>

        <p className={styles.subtitle}>
          Scan the QR or pay using your
          favourite UPI app.
        </p>

        <div className={styles.amount}>
          ₹{amount}
        </div>

        <img
          src={qrCode}
          alt="UPI QR"
          className={styles.qr}
        />

        <div className={styles.instructions}>

          <p>
            ✅ Scan using any UPI app
          </p>

          <p>
            👤 Receiver:
            <strong>
              {" "}
              {settings.receiverName}
            </strong>
          </p>

          <p>
            💰 Amount:
            <strong>
              {" "}
              ₹{amount}
            </strong>
          </p>

          <p>
            📝 Reference:
            <strong>
              {" "}
              {paymentNote}
            </strong>
          </p>

          <div className={styles.warning}>
            ⚠ Please verify that your UPI
            app shows the receiver as
            <strong>
              {" "}
              SAI SUPRAJ S
            </strong>
            .
          </div>

        </div>

        <div className={styles.receiver}>
          <h3>Receiver</h3>
          <p>{settings.receiverName}</p>
        </div>

        <div className={styles.receiver}>
          <h3>UPI ID</h3>
          <p>{settings.upiId}</p>
        </div>

        <div className={styles.receiver}>
          <h3>Payment Note</h3>
          <p>{paymentNote}</p>
        </div>

        <div className={styles.buttons}>

          <button
            className={styles.gpay}
            onClick={openGooglePay}
          >
            🟢 Google Pay
          </button>

          <button
            className={styles.phonepe}
            onClick={openPhonePe}
          >
            🟣 PhonePe
          </button>

          <button
            className={styles.paytm}
            onClick={openPaytm}
          >
            🔵 Paytm
          </button>

        </div>

        <button
          className={styles.copy}
          onClick={copyUpi}
        >
          Copy UPI ID
        </button>

        <button
          className={styles.copy}
          onClick={copyNote}
        >
          Copy Payment Note
        </button>

        <button
          className={styles.done}
          onClick={() =>
            (window.location.href =
              `/student/payments/${registrationId}/proof`)
          }
        >
          I've Completed Payment
        </button>

      </div>
    </div>
  );
}