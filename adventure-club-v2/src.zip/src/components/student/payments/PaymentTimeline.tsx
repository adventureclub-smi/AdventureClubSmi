import styles from "./PaymentTimeline.module.scss";

interface Props {
  registration: any;
}

export default function PaymentTimeline({
  registration,
}: Props) {
  return (
    <div className={styles.timeline}>

      <div className={styles.step}>
        <div className={styles.done}>✓</div>

        <div>
          <h3>Registration Approved</h3>

          <p>
            Your registration has been
            approved.
          </p>
        </div>
      </div>

      <div className={styles.line}></div>

      <div className={styles.step}>

        <div
          className={
            registration.initialPaymentPaid
              ? styles.done
              : registration.paymentReference ||
                registration.paymentScreenshot
              ? styles.waiting
              : styles.pending
          }
        >
          {registration.initialPaymentPaid
            ? "✓"
            : registration.paymentReference ||
              registration.paymentScreenshot
            ? "⏳"
            : "₹"}
        </div>

        <div>

          <h3>Initial Payment</h3>

          <p>

            {registration.initialPaymentPaid
              ? "Payment Verified"

              : registration.paymentReference ||
                registration.paymentScreenshot

              ? "Club will verify it shortly."

              : "Waiting for payment"}

          </p>

        </div>

      </div>

      <div className={styles.line}></div>

      <div className={styles.step}>

        <div
          className={
            registration.initialPaymentPaid
              ? styles.done
              : styles.locked
          }
        >
          📄
        </div>

        <div>

          <h3>Bond Form</h3>

          <p>

            {registration.initialPaymentPaid
              ? "Available"

              : "Locked until payment verification."}

          </p>

        </div>

      </div>

      <div className={styles.line}></div>

      <div className={styles.step}>

        <div
          className={
            registration.finalPaymentPaid
              ? styles.done
              : registration.finalPaymentUnlocked
              ? styles.waiting
              : styles.locked
          }
        >
          💳
        </div>

        <div>

          <h3>Final Payment</h3>

          <p>

            {registration.finalPaymentPaid
              ? "Verified"

              : registration.finalPaymentUnlocked
              ? "Ready to pay"

              : "Locked"}

          </p>

        </div>

      </div>

      <div className={styles.line}></div>

      <div className={styles.step}>

        <div
          className={
            registration.attendanceMarked
              ? styles.done
              : styles.locked
          }
        >
          🥾
        </div>

        <div>

          <h3>Trek Day</h3>

          <p>

            {registration.attendanceMarked
              ? "Checked In"

              : "Upcoming"}

          </p>

        </div>

      </div>

    </div>
  );
}