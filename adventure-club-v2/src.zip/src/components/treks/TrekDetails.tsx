"use client";

import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import styles from "./TrekDetails.module.scss";
import PaymentCountdown from "./PaymentCountdown";

export default function TrekDetails({
  trek,
  user,
  registration,
}: {
  trek: any;
  user: any;
  registration: any;
}) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);

  async function handleRegister() {
    setLoading(true);

    try {
      const res = await fetch("/api/registrations", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          trekId: trek.id,
        }),
      });

      const data = await res.json();

      alert(data.message);

      if (res.ok) {
        router.refresh();
      }
    } catch (error) {
      console.error(error);
      alert("Something went wrong.");
    }

    setLoading(false);
  }

  return (
    <>
      <section className={styles.hero}>
        <Image
          src={trek.coverImage || "/images/default-trek.jpg"}
          alt={trek.title}
          fill
          priority
          className={styles.image}
        />

        <div className={styles.overlay} />

        <div className={styles.content}>
          <p>{trek.destination}</p>

          <h1>{trek.title}</h1>

          <span>
            {new Date(trek.date).toLocaleDateString()}
          </span>
        </div>
      </section>

      <section className={styles.main}>
        <div className={styles.left}>
          <h2>About Expedition</h2>

          <p>{trek.description}</p>
        </div>

        <div className={styles.right}>
          <div className={styles.price}>
            <h2>₹{trek.price}</h2>

            <span>Total Trek Fee</span>
          </div>

          <div className={styles.payments}>
            <div>
              <p>Initial Payment</p>

              <h3>₹{trek.initialPayment}</h3>
            </div>

            <div>
              <p>Final Payment</p>

              <h3>₹{trek.finalPayment}</h3>
            </div>
          </div>

          <div className={styles.divider} />

          <div className={styles.details}>
            <div>
              <span>📅 Date</span>

              <strong>
                {new Date(trek.date).toLocaleDateString()}
              </strong>
            </div>

            <div>
              <span>⛰ Difficulty</span>

              <strong>{trek.difficulty}</strong>
            </div>

            <div>
              <span>📍 Destination</span>

              <strong>{trek.destination}</strong>
            </div>

            <div>
              <span>🕒 Duration</span>

              <strong>{trek.duration}</strong>
            </div>
          </div>

          {/* NOT LOGGED IN */}

          {!user && (
            <>
              <Link
                href="/login"
                className={styles.registerButton}
              >
                Login to Register
              </Link>

              <p className={styles.note}>
                Login to continue your registration.
              </p>
            </>
          )}

          {/* NOT REGISTERED */}

          {user && !registration && (
            <>
              <button
                onClick={handleRegister}
                disabled={loading}
                className={styles.registerButton}
              >
                {loading
                  ? "Registering..."
                  : "Register Now"}
              </button>

              <p className={styles.note}>
                Click Register to submit your
                registration request.
              </p>
            </>
          )}

          {/* WAITING */}

          {registration?.status === "WAITING" && (
            <>
              <button
                disabled
                className={styles.registerButton}
              >
                ✓ Already Registered
              </button>

              <p className={styles.note}>
                Your registration has been
                submitted successfully.
                <br />
                Awaiting admin approval.
              </p>
            </>
          )}

          {/* APPROVED */}

          {registration?.status === "APPROVED" && (
  <>
    {registration.paymentDeadline && (
      <PaymentCountdown
        deadline={registration.paymentDeadline}
      />
    )}

    <button className={styles.registerButton}>
      💳 Pay Initial Payment ₹
      {trek.initialPayment}
    </button>

    <p className={styles.note}>
      Your registration has been approved.
      Complete the initial payment before the
      countdown ends to confirm your seat.
    </p>
  </>

          )}

          {/* REJECTED */}

          {registration?.status === "REJECTED" && (
            <>
              <button
                disabled
                className={styles.registerButton}
              >
                ❌ Registration Rejected
              </button>

              <p className={styles.note}>
                Please contact Adventure Club
                for more details.
              </p>
            </>
          )}

          {/* WAITLIST */}

          {registration?.status === "WAITLIST" && (
            <>
              <button
                disabled
                className={styles.registerButton}
              >
                🟡 Waitlisted
              </button>

              <p className={styles.note}>
                You're currently on the waiting
                list. We'll notify you if a
                seat becomes available.
              </p>
            </>
          )}
        </div>
      </section>
    </>
  );
}