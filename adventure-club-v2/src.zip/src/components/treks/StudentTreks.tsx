"use client";

import { useEffect, useState } from "react";

type Trek = {
  id: string;
  title: string;
  destination: string;
  difficulty: string;
  date: string;
  price: number;
  seats: number;
};

export default function StudentTreks() {
  const [treks, setTreks] = useState<Trek[]>([]);

  useEffect(() => {
    fetch("/api/treks")
      .then((res) => res.json())
      .then((data) => setTreks(data));
  }, []);

  async function register(trekId: string) {
    // We'll replace this with the logged-in user's ID later.
    const userId = "TEMP_USER_ID";

    const res = await fetch("/api/registrations", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        userId,
        trekId,
      }),
    });

    const data = await res.json();

    alert(data.message);
  }

  return (
    <div style={{ padding: 40 }}>
      <h1>Upcoming Treks</h1>

      {treks.map((trek) => (
        <div
          key={trek.id}
          style={{
            border: "1px solid #333",
            padding: 20,
            borderRadius: 12,
            marginTop: 20,
          }}
        >
          <h2>{trek.title}</h2>

          <p>📍 {trek.destination}</p>

          <p>🥾 {trek.difficulty}</p>

          <p>📅 {new Date(trek.date).toLocaleDateString()}</p>

          <button onClick={() => register(trek.id)}>
            Register
          </button>
        </div>
      ))}
    </div>
  );
}