"use client";

import { useEffect, useState } from "react";
import styles from "./PaymentCountdown.module.scss";

export default function PaymentCountdown({
  deadline,
}: {
  deadline: string;
}) {
  const calculate = () => {
    const end = new Date(deadline).getTime();
    const now = new Date().getTime();

    const diff = end - now;

    if (diff <= 0) {
      return null;
    }

    return {
      days: Math.floor(diff / (1000 * 60 * 60 * 24)),
      hours: Math.floor(
        (diff % (1000 * 60 * 60 * 24)) /
          (1000 * 60 * 60)
      ),
      minutes: Math.floor(
        (diff % (1000 * 60 * 60)) /
          (1000 * 60)
      ),
      seconds: Math.floor(
        (diff % (1000 * 60)) / 1000
      ),
    };
  };

  const [time, setTime] = useState(calculate());

  useEffect(() => {
    const timer = setInterval(() => {
      setTime(calculate());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  if (!time) {
    return (
      <div className={styles.expired}>
        <h3>⏰ Payment Deadline Expired</h3>

        <p>
          Please contact the Adventure Club
          for further assistance.
        </p>
      </div>
    );
  }

  const urgent =
    time.days === 0;

  return (
    <div
      className={`${styles.card} ${
        urgent ? styles.urgent : ""
      }`}
    >
      <h3>
        Complete your Initial Payment
      </h3>

      <p>
        Payment closes in
      </p>

      <div className={styles.timer}>
        <div>
          <span>{time.days}</span>

          <small>Days</small>
        </div>

        <div>
          <span>{time.hours}</span>

          <small>Hours</small>
        </div>

        <div>
          <span>{time.minutes}</span>

          <small>Minutes</small>
        </div>

        <div>
          <span>{time.seconds}</span>

          <small>Seconds</small>
        </div>
      </div>

      {urgent && (
        <div className={styles.warning}>
          ⚠️ Less than 24 hours remaining
        </div>
      )}
    </div>
  );
}