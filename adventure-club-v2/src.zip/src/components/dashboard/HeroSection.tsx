"use client";

import styles from "./HeroSection.module.scss";

type Props = {
  name: string;
  clubId: string;
  membership: string;
  role: string;
};

export default function HeroSection({
  name,
  clubId,
  membership,
  role,
}: Props) {
  const hour = new Date().getHours();

  let greeting = "Good Evening";

  if (hour < 12) greeting = "Good Morning";
  else if (hour < 17) greeting = "Good Afternoon";

  return (
    <section className={styles.hero}>
      {/* Background Video */}

      <video
        autoPlay
        muted
        loop
        playsInline
        className={styles.video}
      >
        <source
          src="/videos/drone.mp4"
          type="video/mp4"
        />
      </video>

      {/* Dark Overlay */}

      <div className={styles.overlay} />

      {/* Content */}

      <div className={styles.content}>
        <div>
          <h1>
            {greeting},{" "}
            <span>{name}</span> 👋
          </h1>

          <p>
            Welcome back to Adventure Club.
            Ready for your next summit?
          </p>
        </div>

        <div className={styles.memberCard}>
          <div>
            <small>Membership</small>

            <h3>{membership}</h3>
          </div>

          <div>
            <small>Club Role</small>

            <h3>{role}</h3>
          </div>

          <div>
            <small>Club ID</small>

            <h3>{clubId}</h3>
          </div>
        </div>
      </div>
    </section>
  );
}