"use client";

import { useEffect, useState } from "react";
import styles from "./TripCentre.module.scss";
import Link from "next/link";

interface Trek {
  id: string;
  title: string;
  destination: string;
  date: string;
  coverImage?: string;
}

export default function TripCentre() {
  const [treks, setTreks] = useState<Trek[]>([]);

  useEffect(() => {
    fetch("/api/trip-centre")
      .then((res) => res.json())
      .then((data) => setTreks(data));
  }, []);

  return (
    <div className={styles.container}>
      <h1>Trip Centre</h1>

      <p className={styles.subtitle}>
        All your confirmed upcoming adventures.
      </p>

      {treks.length === 0 ? (
        <div className={styles.empty}>
          No active trips available.
        </div>
      ) : (
        <div className={styles.grid}>
          {treks.map((trek) => (
            <div
              key={trek.id}
              className={styles.card}
            >
              <img
                src={
                  trek.coverImage ||
                  "/images/default-trek.jpg"
                }
                alt={trek.title}
              />

              <div className={styles.content}>
                <h2>{trek.title}</h2>

                <p>
                  📍 {trek.destination}
                </p>

                <p>
                  📅{" "}
                  {new Date(
                    trek.date
                  ).toLocaleDateString()}
                </p>

                <Link href={`/dashboard/trip-centre/${trek.id}`}>
  <button>
    Open Trip Centre
  </button>
</Link>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}