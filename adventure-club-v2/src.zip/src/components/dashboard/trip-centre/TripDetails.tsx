"use client";

import { useEffect, useState } from "react";
import styles from "./TripDetails.module.scss";

export default function TripDetails({
  trekId,
}: {
  trekId: string;
}) {
  const [trek, setTrek] = useState<any>(null);

  const [tab, setTab] = useState("overview");

  useEffect(() => {
    fetch(`/api/trip-centre/${trekId}`)
      .then((res) => res.json())
      .then(setTrek);
  }, [trekId]);

  if (!trek)
    return <div>Loading...</div>;

  return (
    <div className={styles.container}>
      <h1>{trek.title}</h1>

      <div className={styles.tabs}>
        <button
          onClick={() =>
            setTab("overview")
          }
        >
          Overview
        </button>

        <button
          onClick={() =>
            setTab("itinerary")
          }
        >
          Itinerary
        </button>

        <button
          onClick={() =>
            setTab("checklist")
          }
        >
          Checklist
        </button>

        <button
          onClick={() =>
            setTab(
              "announcement"
            )
          }
        >
          Announcements
        </button>
      </div>

      {tab === "overview" && (
        <div className={styles.card}>
          <p>
            📍 {trek.destination}
          </p>

          <p>
            📅{" "}
            {new Date(
              trek.date
            ).toLocaleDateString()}
          </p>

          <p>
            🚌{" "}
            {trek.transportDetails ||
              "To be announced"}
          </p>

          <p>
            📌{" "}
            {trek.meetingPoint ||
              "To be announced"}
          </p>

          <p>
            🕒{" "}
            {trek.meetingTime ||
              "To be announced"}
          </p>

          <p>
            ☎{" "}
            {trek.emergencyNumber ||
              "-"}
          </p>

          <p>
            🌦{" "}
            {trek.weatherNote ||
              "No update"}
          </p>

          <a
            href={
              trek.whatsappGroupLink
            }
            target="_blank"
          >
            Join WhatsApp Group
          </a>
        </div>
      )}

      {tab === "itinerary" && (
        <div className={styles.card}>
          <h2>Itinerary</h2>

          <p>
            {trek.itinerary ||
              "Will be updated by admin."}
          </p>

          <h2>
            Leader's Message
          </h2>

          <p>
            {trek.leaderMessage ||
              "No message."}
          </p>
        </div>
      )}

      {tab === "checklist" && (
        <div className={styles.card}>
          <h2>
            Required Items
          </h2>

          <ul>
            {trek.requiredItems?.map(
              (
                item: string
              ) => (
                <li key={item}>
                  ✅ {item}
                </li>
              )
            )}
          </ul>

          <h2>
            Optional Items
          </h2>

          <ul>
            {trek.optionalItems?.map(
              (
                item: string
              ) => (
                <li key={item}>
                  ⭐ {item}
                </li>
              )
            )}
          </ul>
        </div>
      )}

      {tab ===
        "announcement" && (
        <div className={styles.card}>
          <p>
            Trek announcements
            will appear here.
          </p>
        </div>
      )}
    </div>
  );
}