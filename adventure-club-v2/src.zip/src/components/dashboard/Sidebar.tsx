"use client";

import Link from "next/link";
import Image from "next/image";
import {
  LayoutDashboard,
  User,
  Mountain,
  ClipboardList,
  Bell,
  LogOut,
} from "lucide-react";

import styles from "./Sidebar.module.scss";

export default function Sidebar() {
  return (
    <aside className={styles.sidebar}>
      {/* Logo */}

      <div className={styles.logo}>
        <Image
          src="/logo/logo-white.png"
          alt="Adventure Club"
          width={70}
          height={70}
          priority
        />

        <div>
          <h2>Adventure Club</h2>
          <p>Srishti Manipal</p>
        </div>
      </div>

      {/* Navigation */}

      <nav className={styles.nav}>
        <Link href="/dashboard">
          <LayoutDashboard size={20} />
          Dashboard
        </Link>

        <Link href="/dashboard/profile">
          <User size={20} />
          My Profile
        </Link>

        <Link href="/dashboard/treks">
          <Mountain size={20} />
          Treks
        </Link>

        <Link href="/dashboard/my-registrations">
          <ClipboardList size={20} />
          My Registrations
        </Link>

        <Link href="/dashboard/announcements">
          <Bell size={20} />
          Announcements
        </Link>
      </nav>

      {/* Logout */}

      <button className={styles.logout}>
        <LogOut size={20} />
        Logout
      </button>
    </aside>
  );
}