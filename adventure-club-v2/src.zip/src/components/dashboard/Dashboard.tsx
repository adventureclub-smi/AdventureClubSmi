"use client";

import { useEffect, useState } from "react";

import Sidebar from "./Sidebar";
import HeroSection from "./HeroSection";
import NextTrekCard from "./NextTrekCard";
import Stats from "./Stats";

import styles from "./Dashboard.module.scss";

type HeroData = {
  name: string;
  clubId: string;
  membership: string;
  role: string;
};

type NextTrekData = {
  trek: {
    id: string;
    title: string;
    destination: string;
    date: string;
    difficulty: string;
    price: number;
    initialPayment: number;
    coverImage?: string;
  };

  registration: {
  id: string;

  status: string;

  initialPaymentPaid: boolean;

  offlinePaymentCreated: boolean;

  offlinePaymentVerified: boolean;

  bondFormSubmitted: boolean;

  attendanceMarked: boolean;

  finalPaymentUnlocked: boolean;

  finalPaymentPaid: boolean;

  certificateIssued: boolean;
} | null;

};

export default function Dashboard() {
  const [hero, setHero] =
    useState<HeroData | null>(null);

  const [nextTrek, setNextTrek] =
    useState<NextTrekData | null>(null);

  useEffect(() => {
    loadDashboard();
  }, []);

  async function loadDashboard() {
    try {
      const [heroRes, trekRes] =
        await Promise.all([
          fetch("/api/dashboard/hero"),
          fetch("/api/dashboard/next-trek"),
        ]);

      if (heroRes.ok) {
        setHero(await heroRes.json());
      }

      if (trekRes.ok) {
        setNextTrek(await trekRes.json());
      }
    } catch (err) {
      console.error(err);
    }
  }

  return (
    <div className={styles.dashboard}>
      <Sidebar />

      <main className={styles.main}>
        {hero && (
          <HeroSection
            name={hero.name}
            clubId={hero.clubId}
            membership={hero.membership}
            role={hero.role}
          />
        )}

        {nextTrek?.trek && (
          <NextTrekCard
            trek={nextTrek.trek}
            registration={
              nextTrek.registration
            }
          />
        )}

        <Stats />
      </main>
    </div>
  );
}