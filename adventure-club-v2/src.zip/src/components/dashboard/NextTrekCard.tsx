"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import styles from "./NextTrekCard.module.scss";

type Trek = {
  id: string;
  title: string;
  destination: string;
  date: string;
  coverImage?: string;
  difficulty: string;
  price: number;
  initialPayment: number;
};

type Registration = {
  id: string;

  status: string;

  initialPaymentDeadline?: string | null;

  initialPaymentPaid: boolean;

  offlinePaymentCreated: boolean;

  offlinePaymentVerified: boolean;

  bondFormSubmitted: boolean;

  attendanceMarked: boolean;

  finalPaymentUnlocked: boolean;

  finalPaymentPaid: boolean;

  certificateIssued: boolean;
};

type Props = {
  trek: Trek;

  registration: Registration | null;

  registrationState?: "NOT_OPEN" | "OPEN" | "CLOSED";

  registrationOpensAt?: string | null;
};

export default function NextTrekCard({
  trek,
  registration,
  registrationState,
  registrationOpensAt,
}: Props) {
  const router = useRouter();

  const [countdown, setCountdown] =
    useState("");

  useEffect(() => {
    const interval = setInterval(() => {
      const now = Date.now();

      // Registration Countdown
      if (
        registrationState === "NOT_OPEN" &&
        registrationOpensAt
      ) {
        const target = new Date(
          registrationOpensAt
        ).getTime();

        const diff = target - now;

        if (diff <= 0) {
          setCountdown(
            "Registrations Opening..."
          );
          return;
        }

        const days = Math.floor(
          diff /
            (1000 * 60 * 60 * 24)
        );

        const hours = Math.floor(
          (diff %
            (1000 *
              60 *
              60 *
              24)) /
            (1000 * 60 * 60)
        );

        const mins = Math.floor(
          (diff %
            (1000 * 60 * 60)) /
            (1000 * 60)
        );

        setCountdown(
          `${days}d ${hours}h ${mins}m`
        );

        return;
      }

      // Payment Deadline
      const target =
        registration
          ?.initialPaymentDeadline
          ? new Date(
              registration.initialPaymentDeadline
            ).getTime()
          : new Date(
              trek.date
            ).getTime();

      const diff = target - now;

      if (diff <= 0) {
        setCountdown(
          registration
            ?.initialPaymentDeadline
            ? "Payment Deadline Passed"
            : "Trek Started"
        );

        return;
      }

      const days = Math.floor(
        diff /
          (1000 * 60 * 60 * 24)
      );

      const hours = Math.floor(
        (diff %
          (1000 * 60 * 60 * 24)) /
          (1000 * 60 * 60)
      );

      const mins = Math.floor(
        (diff %
          (1000 * 60 * 60)) /
          (1000 * 60)
      );

      setCountdown(
        `${days}d ${hours}h ${mins}m`
      );
    }, 1000);

    return () =>
      clearInterval(interval);
  }, [
    trek.date,
    registration,
    registrationState,
    registrationOpensAt,
  ]);

  // Continue with Part 2...

  const badge = useMemo(() => {
  if (!registration) {
    switch (registrationState) {
      case "NOT_OPEN":
        return {
          text: "Registration Opens Soon",
          color: styles.waiting,
        };

      case "CLOSED":
        return {
          text: "Registrations Closed",
          color: styles.rejected,
        };

      default:
        return {
          text: "Registration Open",
          color: styles.open,
        };
    }
  }

  switch (registration.status) {
    case "WAITING":
      return {
        text: "Waiting Approval",
        color: styles.waiting,
      };

    case "APPROVED":
      return {
        text: "Approved",
        color: styles.approved,
      };

    case "WAITLIST":
      return {
        text: "Waitlisted",
        color: styles.waitlist,
      };

    case "REJECTED":
      return {
        text: "Rejected",
        color: styles.rejected,
      };

    case "COMPLETED":
      return {
        text: "Completed",
        color: styles.completed,
      };

    default:
      return {
        text: "",
        color: "",
      };
  }
}, [registration, registrationState]);

const timeline = [
  {
    title: "Registration",
    done: !!registration,
    subtitle: registration
      ? "Successfully Registered"
      : registrationState === "NOT_OPEN"
      ? "Opens Soon"
      : registrationState === "CLOSED"
      ? "Closed"
      : "Open",
  },

  {
    title: "Approval",
    done:
      registration?.status === "APPROVED" ||
      registration?.status === "COMPLETED",

    subtitle:
      registration?.status === "WAITING"
        ? "Waiting for Admin"
        : registration?.status === "APPROVED"
        ? "Approved"
        : "Pending",
  },

  {
    title: "Initial Payment",

    done:
      registration?.initialPaymentPaid ||
      registration?.offlinePaymentVerified,

    subtitle:
      registration?.initialPaymentPaid ||
      registration?.offlinePaymentVerified
        ? "Verified"
        : registration?.offlinePaymentCreated
        ? "Verification Pending"
        : "Pending",
  },

  {
    title: "Bond Form",

    done:
      registration?.bondFormSubmitted,

    subtitle:
      registration?.bondFormSubmitted
        ? "Submitted"
        : "Pending",
  },

  {
    title: "Trip Centre",

    done:
      registration?.status === "APPROVED",

    subtitle:
      registration?.status === "APPROVED"
        ? "Available"
        : "Locked",
  },

  {
    title: "Final Payment",

    done:
      registration?.finalPaymentPaid,

    subtitle:
      registration?.finalPaymentUnlocked
        ? registration?.finalPaymentPaid
          ? "Verified"
          : "Ready to Pay"
        : "Locked",
  },

  {
    title: "Attendance",

    done:
      registration?.attendanceMarked,

    subtitle:
      registration?.attendanceMarked
        ? "Present"
        : "Pending Trek",
  },

  {
    title: "Certificate",

    done:
      registration?.certificateIssued,

    subtitle:
      registration?.certificateIssued
        ? "Issued"
        : "Optional",
  },

  {
    title: "Trip Completed",

    done:
      registration?.attendanceMarked,

    subtitle:
      registration?.attendanceMarked
        ? "Adventure Completed"
        : "Upcoming",
  },
];

function getAction() {
  // ----------------------------
  // Registration not done yet
  // ----------------------------

  if (!registration) {
    if (registrationState === "NOT_OPEN")
      return {
        text: "Registration Opens Soon",
        className: styles.disabled,
      };

    if (registrationState === "CLOSED")
      return {
        text: "Registrations Closed",
        className: styles.disabled,
      };

    return {
      text: "Register Now",
      className: styles.register,
    };
  }

  // ----------------------------
  // Waiting Approval
  // ----------------------------

  if (registration.status === "WAITING")
    return {
      text: "Waiting for Approval",
      className: styles.disabled,
    };

  // ----------------------------
  // Initial Payment Submitted
  // ----------------------------

  if (
    registration.status === "APPROVED" &&
    registration.offlinePaymentCreated &&
    !registration.offlinePaymentVerified
  ) {
    return {
      text:
        "Waiting for Initial Payment Verification",
      className: styles.disabled,
    };
  }

  // ----------------------------
  // Initial Payment Pending
  // ----------------------------

  if (
    registration.status === "APPROVED" &&
    !registration.initialPaymentPaid &&
    !registration.offlinePaymentCreated
  ) {
    return {
      text: "Pay Initial Payment",
      className: styles.pay,
    };
  }

  // ----------------------------
  // Trip Centre
  // ----------------------------

  if (
    registration.initialPaymentPaid &&
    !registration.finalPaymentUnlocked
  ) {
    return {
      text: "Open Trip Centre",
      className: styles.tripCentre,
    };
  }

  // ----------------------------
  // Final Payment
  // ----------------------------

  if (
    registration.finalPaymentUnlocked &&
    !registration.finalPaymentPaid
  ) {
    return {
      text: "Pay Final Payment",
      className: styles.finalPay,
    };
  }

  // ----------------------------
  // Attendance
  // ----------------------------

  if (
    registration.finalPaymentPaid &&
    !registration.attendanceMarked
  ) {
    return {
      text: "Waiting for Trek Day",
      className: styles.disabled,
    };
  }

  // ----------------------------
  // Certificate
  // ----------------------------

  if (
    registration.attendanceMarked &&
    !registration.certificateIssued
  ) {
    return {
      text: "Trip Completed",
      className: styles.tripCentre,
    };
  }

  if (registration.certificateIssued)
    return {
      text: "Download Certificate",
      className: styles.certificate,
    };

  return {
    text: "View Trek",
    className: styles.tripCentre,
  };
}

function handleAction() {
  // Registration
  if (!registration) {
    if (registrationState !== "OPEN")
      return;

    router.push(`/treks/${trek.id}`);
    return;
  }

  // Initial Payment
  if (
    registration.status === "APPROVED" &&
    !registration.offlinePaymentCreated
  ) {
    router.push(
      `/student/payments/${registration.id}`
    );

    return;
  }

  // Trip Centre
  if (
    registration.initialPaymentPaid &&
    !registration.finalPaymentUnlocked
  ) {
    router.push(
      `/trip-centre/${trek.id}`
    );

    return;
  }

  // Final Payment
  if (
    registration.finalPaymentUnlocked &&
    !registration.finalPaymentPaid
  ) {
    router.push(
      `/student/payments/${registration.id}?type=FINAL`
    );

    return;
  }

  // Trip Centre after Final Payment
  if (
    registration.finalPaymentPaid
  ) {
    router.push(
      `/trip-centre/${trek.id}`
    );

    return;
  }
}

const action = getAction();

return (
  <section className={styles.card}>
    {/* LEFT */}

    <div className={styles.imageSection}>
      <img
        src={
          trek.coverImage ||
          "/images/default-trek.jpg"
        }
        alt={trek.title}
      />
    </div>

    {/* CENTER */}

    <div className={styles.detailsSection}>
      <div className={styles.header}>
        <div>
          <small>FEATURED TREK</small>

          <h2>{trek.title}</h2>

          <p>📍 {trek.destination}</p>

          <p>
            📅{" "}
            {new Date(
              trek.date
            ).toLocaleDateString("en-IN", {
              day: "numeric",
              month: "long",
              year: "numeric",
            })}
          </p>
        </div>

        <span className={badge.color}>
          {badge.text}
        </span>
      </div>

      <div className={styles.infoGrid}>
        <div>
          <span>Difficulty</span>

          <strong>
            {trek.difficulty}
          </strong>
        </div>

        <div>
          <span>Total Cost</span>

          <strong>
            ₹{trek.price}
          </strong>
        </div>

        <div>
          <span>Initial</span>

          <strong>
            ₹{trek.initialPayment}
          </strong>
        </div>

        <div>
          <span>
            {registrationState ===
            "NOT_OPEN"
              ? "Registration Opens"
              : registration
                  ?.initialPaymentDeadline
              ? "Payment Deadline"
              : "Countdown"}
          </span>

          <strong>
            {countdown}
          </strong>
        </div>
      </div>

      <button
        className={action.className}
        onClick={handleAction}
      >
        {action.text}
      </button>
    </div>

    {/* RIGHT */}

    <div className={styles.timelineSection}>
      <h3>Adventure Journey</h3>

      {timeline.map((step) => (
        <div
          key={step.title}
          className={
            styles.timelineItem
          }
        >
          <div
            className={
              step.done
                ? styles.timelineDone
                : styles.timelinePending
            }
          >
            {step.done
              ? "✓"
              : ""}
          </div>

          <div>
            <strong>
              {step.title}
            </strong>

            <p>
              {step.subtitle}
            </p>
          </div>
        </div>
      ))}
    </div>
  </section>
);
}