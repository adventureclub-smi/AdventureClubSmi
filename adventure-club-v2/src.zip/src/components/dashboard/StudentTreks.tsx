"use client";

import { useEffect, useState } from "react";
import styles from "./StudentTreks.module.scss";

type Trek = {
  id: string;
  title: string;
  destination: string;
  date: string;
  difficulty: string;
  price: number;
  altitude: string;
  distance: string;
  coverImage?: string;
};

export default function StudentTreks() {
  const [treks, setTreks] = useState<Trek[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadTreks() {
      const res = await fetch("/api/my-treks");

      const data = await res.json();

      if (res.ok) {
        setTreks(data);
      }

      setLoading(false);
    }

    loadTreks();
  }, []);

  if (loading) {
    return (
      <div className={styles.container}>
        <h1>Completed Treks</h1>
        <p>Loading...</p>
      </div>
    );
  }

  if (treks.length === 0) {
    return (
      <div className={styles.container}>
        <h1>Completed Treks</h1>

        <div className={styles.empty}>
          <h2>No completed treks yet.</h2>

          <p>Your adventures will appear here.</p>
        </div>
      </div>
    );
  }

  return (
    <div className={styles.container}>
      <h1>Completed Treks</h1>

      <div className={styles.grid}>
        {treks.map((trek) => (
          <div
            key={trek.id}
            className={styles.card}
          >
            <img
              src={
                trek.coverImage ||
                "/images/default-trek.jpg"
              }
              alt={trek.title}
            />

            <div className={styles.content}>
              <h2>{trek.title}</h2>

              <p>📍 {trek.destination}</p>

              <p>
                📅{" "}
                {new Date(
                  trek.date
                ).toLocaleDateString()}
              </p>

              <p>🥾 {trek.difficulty}</p>

              <p>📏 {trek.distance}</p>

              <p>⛰️ {trek.altitude}</p>

              <p>💰 ₹{trek.price}</p>

              <span className={styles.badge}>
                COMPLETED
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}