"use client";

import { useEffect, useState } from "react";
import styles from "./Profile.module.scss";

export default function Profile() {
  const [loading, setLoading] = useState(true);

  const [saving, setSaving] = useState(false);

  const [user, setUser] = useState<any>({
    fullName: "",
    email: "",
    phoneNumber: "",
    upiId: "",

upiPhone: "",
    institution: "",
    department: "",
    year: "",

    bloodGroup: "",

    dateOfBirth: "",

    collegeRollNumber: "",

    emergencyContactName: "",

    emergencyContactRelation: "",

    emergencyContactPhone: "",

    clubId: "",

    membershipStatus: "",

    clubRole: "",
  });

  useEffect(() => {
    loadProfile();
  }, []);

  async function loadProfile() {
    const res = await fetch("/api/profile");

    const data = await res.json();

    setUser({
  ...data,

  dateOfBirth: data.dateOfBirth
    ? data.dateOfBirth.slice(0, 10)
    : "",

  upiId: data.upiId || "",

  upiPhone: data.upiPhone || "",

  phoneNumber: data.phoneNumber || "",

  emergencyContactName:
    data.emergencyContactName || "",

  emergencyContactRelation:
    data.emergencyContactRelation || "",

  emergencyContactPhone:
    data.emergencyContactPhone || "",
});

    setLoading(false);
  }

  async function saveProfile() {
    setSaving(true);

    await fetch("/api/profile", {
      method: "PUT",

      headers: {
        "Content-Type": "application/json",
      },

      body: JSON.stringify(user),
    });

    setSaving(false);

    alert("Profile Updated Successfully!");
  }

  function handleChange(
    e: React.ChangeEvent<
      HTMLInputElement
    >
  ) {
    setUser({
      ...user,
      [e.target.name]: e.target.value,
    });
  }

  if (loading)
    return <p>Loading...</p>;

    return (
    <div className={styles.container}>
      <div className={styles.header}>
        <div>
          <h1>My Profile</h1>
          <p>
            Keep your details updated for a smoother trekking experience.
          </p>
        </div>

        <button
          onClick={saveProfile}
          disabled={saving}
        >
          {saving ? "Saving..." : "Save Changes"}
        </button>
      </div>

      <div className={styles.grid}>

        {/* PERSONAL INFORMATION */}

        <section className={styles.card}>
          <h2>Personal Information</h2>

          <div className={styles.fields}>
            <div>
              <label>Full Name</label>

              <input
                name="fullName"
                value={user.fullName}
                onChange={handleChange}
              />
            </div>

            <div>
              <label>Date of Birth</label>

              <input
                type="date"
                name="dateOfBirth"
                value={user.dateOfBirth}
                onChange={handleChange}
              />
            </div>

            <div>
              <label>Blood Group</label>

              <input
                name="bloodGroup"
                value={user.bloodGroup}
                onChange={handleChange}
                placeholder="O+, A+, B+, AB+..."
              />
            </div>

            <div>
              <label>College Roll Number</label>

              <input
                name="collegeRollNumber"
                value={user.collegeRollNumber}
                onChange={handleChange}
              />
            </div>
          </div>
        </section>

        {/* CONTACT */}

        <section className={styles.card}>
          <h2>Contact Details</h2>

          <div className={styles.fields}>
            <div>
              <label>Email</label>

              <input
                value={user.email}
                disabled
              />
            </div>

            <div>
              <label>Phone Number</label>

              <input
                name="phoneNumber"
                value={user.phoneNumber}
                onChange={handleChange}
              />
            </div>
          </div>
        </section>

        {/* REIMBURSEMENT */}

<section className={styles.card}>
  <h2>Reimbursement Details</h2>

  <p className={styles.note}>
    These details will automatically be used
    for any reimbursement after a trek.
    You can update them anytime.
  </p>

  <div className={styles.fields}>
    <div>
      <label>UPI ID</label>

      <input
        name="upiId"
        value={user.upiId}
        onChange={handleChange}
        placeholder="example@oksbi"
      />
    </div>

    <div>
      <label>UPI Phone Number</label>

      <input
        name="upiPhone"
        value={user.upiPhone}
        onChange={handleChange}
        placeholder="9876543210"
      />
    </div>
  </div>
</section>

        {/* ACADEMIC */}

        <section className={styles.card}>
          <h2>Academic Information</h2>

          <div className={styles.fields}>
            <div>
              <label>Institution</label>

              <input
                name="institution"
                value={user.institution}
                onChange={handleChange}
              />
            </div>

            <div>
              <label>Department</label>

              <input
                name="department"
                value={user.department}
                onChange={handleChange}
              />
            </div>

            <div>
              <label>Year</label>

              <input
                name="year"
                value={user.year}
                onChange={handleChange}
              />
            </div>
          </div>
        </section>

                {/* EMERGENCY CONTACT */}

        <section className={styles.card}>
          <h2>Emergency Contact</h2>

          <div className={styles.fields}>
            <div>
              <label>Name</label>

              <input
                name="emergencyContactName"
                value={user.emergencyContactName}
                onChange={handleChange}
              />
            </div>

            <div>
              <label>Relationship</label>

              <input
                name="emergencyContactRelation"
                value={user.emergencyContactRelation}
                onChange={handleChange}
              />
            </div>

            <div>
              <label>Phone Number</label>

              <input
                name="emergencyContactPhone"
                value={user.emergencyContactPhone}
                onChange={handleChange}
              />
            </div>
          </div>
        </section>

        {/* CLUB INFORMATION */}

        <section className={styles.card}>
          <h2>Club Information</h2>

          <div className={styles.fields}>
            <div>
              <label>Club ID</label>

              <input
                value={user.clubId}
                disabled
              />
            </div>

            <div>
              <label>Membership Status</label>

              <input
                value={user.membershipStatus}
                disabled
              />
            </div>

            <div>
              <label>Club Role</label>

              <input
                value={user.clubRole}
                disabled
              />
            </div>
          </div>

          <small className={styles.note}>
            These details can only be updated by the
            club administration.
          </small>
        </section>

        {/* SECURITY */}

        <section className={styles.card}>
          <h2>Security</h2>

          <p className={styles.passwordText}>
            Password changes will be available from a
            dedicated security page.
          </p>

          <button
            className={styles.passwordButton}
            type="button"
          >
            Change Password
          </button>
        </section>

      </div>
    </div>
  );
}