"use client";

import { useEffect, useState } from "react";

interface Registration {
  id: string;
  status: string;

  trek: {
    title: string;
    destination: string;
    date: string;
  };
}

export default function MyRegistrations() {
  const [registrations, setRegistrations] = useState<Registration[]>([]);

  useEffect(() => {
  async function loadRegistrations() {
    const res = await fetch("/api/my-registrations");

    const data = await res.json();

    if (res.ok) {
      setRegistrations(data);
    } else {
      console.error(data.message);
    }
  }

  loadRegistrations();
}, []);

  return (
    <div style={{ padding: "40px" }}>
      <h1>My Registrations</h1>

      {registrations.length === 0 ? (
        <p>No registrations yet.</p>
      ) : (
        registrations.map((registration) => (
          <div
            key={registration.id}
            style={{
              border: "1px solid #333",
              padding: "20px",
              marginTop: "20px",
              borderRadius: "10px",
            }}
          >
            <h2>{registration.trek.title}</h2>

            <p>{registration.trek.destination}</p>

            <p>
              {new Date(registration.trek.date).toLocaleDateString()}
            </p>

            <strong>Status:</strong>{" "}
            {registration.status}
          </div>
        ))
      )}
    </div>
  );
}