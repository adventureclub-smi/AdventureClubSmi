"use client";

import { useEffect, useState } from "react";
import {
  Mountain,
  Footprints,
  MoonStar,
  Award,
  Route,
  TrendingUp,
} from "lucide-react";

import styles from "./Stats.module.scss";

type Stats = {
  totalTreks: number;
  peaks: number;
  totalKm: number;
  totalNights: number;
  certificates: number;
  highestAltitude: number;
};

export default function Stats() {
  const [stats, setStats] = useState<Stats>({
    totalTreks: 0,
    peaks: 0,
    totalKm: 0,
    totalNights: 0,
    certificates: 0,
    highestAltitude: 0,
  });

  useEffect(() => {
    loadStats();
  }, []);

  async function loadStats() {
    try {
      const res = await fetch("/api/dashboard/stats");

      if (!res.ok) return;

      const data = await res.json();

      setStats(data);
    } catch (err) {
      console.error(err);
    }
  }

  const cards = [
    {
      icon: Footprints,
      title: "Treks Attended",
      value: stats.totalTreks,
    },
    {
      icon: Mountain,
      title: "Peaks Climbed",
      value: stats.peaks,
    },
    {
      icon: Route,
      title: "Distance Trekked",
      value: `${stats.totalKm} km`,
    },
    {
      icon: MoonStar,
      title: "Camp Nights",
      value: stats.totalNights,
    },
    {
      icon: Award,
      title: "Certificates",
      value: stats.certificates,
    },
    {
      icon: TrendingUp,
      title: "Highest Altitude",
      value: `${stats.highestAltitude} m`,
    },
  ];

  return (
    <>
      <h2 className={styles.heading}>
        Adventure Statistics
      </h2>

      <section className={styles.grid}>
        {cards.map((card) => {
          const Icon = card.icon;

          return (
            <div
              key={card.title}
              className={styles.card}
            >
              <div className={styles.icon}>
                <Icon size={26} />
              </div>

              <h3>{card.value}</h3>

              <p>{card.title}</p>
            </div>
          );
        })}
      </section>
    </>
  );
}